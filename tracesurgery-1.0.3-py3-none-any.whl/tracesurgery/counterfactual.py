from __future__ import annotations

"""Executed counterfactual trajectory surgery.

Causal claims are admissible only at checkpoints where an exact no-intervention
replay reproduces the source trajectory's terminal state. This avoids treating
nondeterministic replay drift as an intervention effect.
"""

from dataclasses import dataclass, asdict
from enum import Enum
from itertools import combinations
from typing import Iterable, Sequence

from pydantic import BaseModel, Field

from tracesurgery.core.models import Action, Task, TrialResult
from tracesurgery.graders.composite import CompositeGrader
from tracesurgery.provenance import stable_hash, action_hashes


class SurgeryKind(str, Enum):
    NO_INTERVENTION = "no_intervention"
    ACTION_PATCH = "action_patch"
    STATE_PATCH = "state_patch"
    SUFFIX_REPLAN = "suffix_replan"


class DiagnosisClaim(BaseModel):
    """A debugger's falsifiable causal claim.

    `step` is the predicted causal location and `repair_kind` is the
    preregistered intervention used to test that claim.
    """

    step: int = Field(ge=0)
    repair_kind: SurgeryKind = SurgeryKind.ACTION_PATCH
    label: str | None = None
    confidence: float | None = Field(default=None, ge=0, le=1)


@dataclass(frozen=True)
class BranchResult:
    task_id: str
    source_trial_id: str
    intervention_step: int
    kind: str
    success: bool
    baseline_success: bool
    outcome_gain: int
    final_state: dict
    n_replayed_actions: int
    metadata: dict
    source_checkpoint_hash: str
    continuation_hash: str
    final_state_hash: str
    replay_matches_source: bool | None = None
    causally_usable: bool | None = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class RecoverySurface:
    task_id: str
    source_trial_id: str
    branches: list[BranchResult]

    def by_kind(self, kind: SurgeryKind | str, *, usable_only: bool = False) -> list[BranchResult]:
        value = kind.value if isinstance(kind, SurgeryKind) else kind
        xs = [b for b in self.branches if b.kind == value]
        return [b for b in xs if b.causally_usable] if usable_only else xs

    def control_fidelity_by_step(self) -> dict[int, bool]:
        return {
            b.intervention_step: bool(b.replay_matches_source)
            for b in self.by_kind(SurgeryKind.NO_INTERVENTION)
        }

    def admissible_steps(self) -> list[int]:
        return sorted(step for step, ok in self.control_fidelity_by_step().items() if ok)

    def last_recoverable_step(self, kind: SurgeryKind | str) -> int | None:
        xs = [b.intervention_step for b in self.by_kind(kind, usable_only=True) if b.success]
        return max(xs) if xs else None

    def recovery_auc(self, kind: SurgeryKind | str) -> float | None:
        """Discrete recovery AUC over replay-faithful checkpoints only."""
        xs = self.by_kind(kind, usable_only=True)
        return sum(int(b.success) for b in xs) / len(xs) if xs else None

    def minimal_sufficient_repairs(self) -> list[BranchResult]:
        """Successful one-step action patches (not a global minimum-set claim)."""
        return [b for b in self.by_kind(SurgeryKind.ACTION_PATCH, usable_only=True) if b.success]

    def to_dict(self) -> dict:
        return {
            "task_id": self.task_id,
            "source_trial_id": self.source_trial_id,
            "branches": [b.to_dict() for b in self.branches],
            "control_fidelity_by_step": self.control_fidelity_by_step(),
            "admissible_steps": self.admissible_steps(),
            "summary": {
                k.value: {
                    "last_recoverable_step": self.last_recoverable_step(k),
                    "recovery_auc": self.recovery_auc(k),
                }
                for k in SurgeryKind
            },
            "successful_single_action_repairs": [
                b.intervention_step for b in self.minimal_sufficient_repairs()
            ],
        }


class CounterfactualSurgeon:
    """Executes checkpointed counterfactual branches over a failed trajectory."""

    def __init__(self, environment, grader=None):
        self.environment = environment
        self.grader = grader or CompositeGrader()
        if not hasattr(environment, "restore"):
            raise TypeError("environment must implement restore(snapshot)")

    @staticmethod
    def _oracle_actions(task: Task) -> list[Action]:
        raw = task.metadata.get("script", [])
        return [x if isinstance(x, Action) else Action.model_validate(x) for x in raw]

    @staticmethod
    def _failed_actions(trial: TrialResult) -> list[Action]:
        return [s.action for s in trial.trajectory]

    @staticmethod
    def _assert_kind_allowed(task: Task, kind: SurgeryKind) -> None:
        if kind == SurgeryKind.NO_INTERVENTION:
            return
        allowed = task.metadata.get("valid_surgeries")
        if allowed is not None and kind.value not in set(allowed):
            raise ValueError(f"{kind.value} is not semantically valid for task {task.id}")

    def _execute_from(self, task: Task, checkpoint: dict, actions: Iterable[Action]) -> tuple[dict, int]:
        self.environment.reset(task, seed=0)
        self.environment.restore(checkpoint)
        n = 0
        for action in actions:
            if self.environment.is_terminal():
                break
            self.environment.step(action)
            n += 1
        return self.environment.snapshot(), n

    def branch(
        self,
        task: Task,
        failed_trial: TrialResult,
        step: int,
        kind: SurgeryKind,
        oracle_trial: TrialResult | None = None,
    ) -> BranchResult:
        if failed_trial.success:
            raise ValueError("counterfactual surgery expects a failed source trial")
        if not (0 <= step < len(failed_trial.trajectory)):
            raise IndexError(step)
        self._assert_kind_allowed(task, kind)

        failed_actions = self._failed_actions(failed_trial)
        oracle_actions = self._oracle_actions(task)
        if step >= len(oracle_actions):
            raise ValueError("oracle script does not cover requested intervention step")

        failed_checkpoint = failed_trial.trajectory[step].environment_state_before
        checkpoint = failed_checkpoint
        continuation = list(failed_actions[step:])
        metadata: dict = {}

        if kind == SurgeryKind.NO_INTERVENTION:
            metadata["control"] = "replay_same_checkpoint_and_suffix"
        elif kind == SurgeryKind.ACTION_PATCH:
            continuation[0] = oracle_actions[step]
            metadata["patched_action"] = oracle_actions[step].model_dump()
        elif kind == SurgeryKind.STATE_PATCH:
            if oracle_trial is None:
                raise ValueError("state_patch requires an oracle trial")
            if step >= len(oracle_trial.trajectory):
                raise ValueError("oracle trial does not cover requested intervention step")
            checkpoint = oracle_trial.trajectory[step].environment_state_before
            metadata["checkpoint_source"] = "oracle_pre_state"
        elif kind == SurgeryKind.SUFFIX_REPLAN:
            continuation = list(oracle_actions[step:])
            metadata["continuation_source"] = "oracle_suffix"
        else:
            raise ValueError(kind)

        final, n = self._execute_from(task, checkpoint, continuation)
        success = bool(self.grader.grade(task, final)["success"])
        source_final_hash = stable_hash(failed_trial.final_state)
        final_hash = stable_hash(final)
        replay_matches = final_hash == source_final_hash if kind == SurgeryKind.NO_INTERVENTION else None
        return BranchResult(
            task_id=task.id,
            source_trial_id=failed_trial.trial_id,
            intervention_step=step,
            kind=kind.value,
            success=success,
            baseline_success=bool(failed_trial.success),
            outcome_gain=int(success) - int(failed_trial.success),
            final_state=final,
            n_replayed_actions=n,
            metadata=metadata,
            source_checkpoint_hash=stable_hash(checkpoint),
            continuation_hash=stable_hash(action_hashes(continuation)),
            final_state_hash=final_hash,
            replay_matches_source=replay_matches,
            causally_usable=replay_matches if kind == SurgeryKind.NO_INTERVENTION else None,
        )

    def sweep(
        self,
        task: Task,
        failed_trial: TrialResult,
        oracle_trial: TrialResult,
        kinds: tuple[SurgeryKind, ...] = (
            SurgeryKind.NO_INTERVENTION,
            SurgeryKind.ACTION_PATCH,
            SurgeryKind.STATE_PATCH,
            SurgeryKind.SUFFIX_REPLAN,
        ),
    ) -> RecoverySurface:
        usable = min(len(failed_trial.trajectory), len(self._oracle_actions(task)))
        # Controls first, because causal admissibility of all interventions at a
        # checkpoint depends on replay fidelity at that checkpoint.
        controls = {
            step: self.branch(task, failed_trial, step, SurgeryKind.NO_INTERVENTION, oracle_trial)
            for step in range(usable)
        }
        branches: list[BranchResult] = []
        requested = tuple(k for k in kinds if k != SurgeryKind.NO_INTERVENTION)
        for step in range(usable):
            control = controls[step]
            # Controls are always retained in the surface, even if the caller
            # requests only intervention families; otherwise causal provenance
            # would be impossible to audit from the serialized surface alone.
            branches.append(control)
            for kind in requested:
                b = self.branch(task, failed_trial, step, kind, oracle_trial)
                b = BranchResult(**{**b.to_dict(), "causally_usable": bool(control.replay_matches_source)})
                branches.append(b)
        return RecoverySurface(task.id, failed_trial.trial_id, branches)

    def diagnosis_faithfulness(
        self,
        task: Task,
        failed_trial: TrialResult,
        oracle_trial: TrialResult,
        claims: Sequence[DiagnosisClaim],
    ) -> dict:
        """Execute a debugger's preregistered causal claims.

        A claim is faithful only if its repair flips the failed outcome and the
        checkpoint passes the no-intervention replay-fidelity control.
        """
        rows = []
        for claim in claims:
            control = self.branch(task, failed_trial, claim.step, SurgeryKind.NO_INTERVENTION, oracle_trial)
            repair = self.branch(task, failed_trial, claim.step, claim.repair_kind, oracle_trial)
            usable = bool(control.replay_matches_source)
            faithful = bool(usable and repair.outcome_gain > 0)
            rows.append({
                "step": claim.step,
                "repair_kind": claim.repair_kind.value,
                "label": claim.label,
                "confidence": claim.confidence,
                "control_fidelity": usable,
                "outcome_gain": repair.outcome_gain if usable else None,
                "faithful": faithful,
            })
        eligible = [r for r in rows if r["control_fidelity"]]
        return {
            "claims": rows,
            "n_claims": len(rows),
            "n_evaluable": len(eligible),
            "faithfulness": (sum(r["faithful"] for r in eligible) / len(eligible)) if eligible else None,
        }

    def minimal_action_repair_sets(
        self,
        task: Task,
        failed_trial: TrialResult,
        oracle_trial: TrialResult,
        *,
        candidate_steps: Sequence[int] | None = None,
        max_edits: int = 2,
    ) -> list[dict]:
        """Search for minimum-cardinality oracle action-patch sets.

        This is intended as an evaluator upper-bound / causal probe, not as an
        agent recovery algorithm. Search is combinatorial and therefore bounded
        by `max_edits` and an explicit candidate set in paper-scale use.
        """
        failed_actions = self._failed_actions(failed_trial)
        oracle_actions = self._oracle_actions(task)
        usable_n = min(len(failed_actions), len(oracle_actions))
        candidates = list(candidate_steps) if candidate_steps is not None else list(range(usable_n))
        candidates = [s for s in candidates if 0 <= s < usable_n]
        found: list[dict] = []
        for k in range(1, max_edits + 1):
            for subset in combinations(candidates, k):
                first = min(subset)
                control = self.branch(task, failed_trial, first, SurgeryKind.NO_INTERVENTION, oracle_trial)
                if not control.replay_matches_source:
                    continue
                checkpoint = failed_trial.trajectory[first].environment_state_before
                continuation = list(failed_actions[first:])
                for s in subset:
                    continuation[s - first] = oracle_actions[s]
                final, n = self._execute_from(task, checkpoint, continuation)
                success = bool(self.grader.grade(task, final)["success"])
                if success:
                    found.append({
                        "steps": list(subset),
                        "n_edits": k,
                        "success": True,
                        "n_replayed_actions": n,
                        "final_state_hash": stable_hash(final),
                    })
            if found:
                return found
        return found
