from __future__ import annotations

"""Contracts for external model/environment integrations.

Concrete OSWorld/BrowserGym/provider implementations should live outside the
core or in optional extras.  These protocols make integration testable without
pretending the external systems exist in this release environment.
"""

from typing import Protocol, runtime_checkable, Any
from tracesurgery.core.models import Action, Observation, Task


@runtime_checkable
class ProviderAdapter(Protocol):
    name: str
    model_revision: str
    def reset(self, *, seed: int) -> None: ...
    def act(self, observation: Observation, task: Task) -> Action: ...
    def close(self) -> None: ...


@runtime_checkable
class StatefulEnvironmentAdapter(Protocol):
    name: str
    version: str
    def reset(self, task: Task, seed: int = 0) -> Observation: ...
    def step(self, action: Action) -> Observation: ...
    def snapshot(self) -> dict[str, Any]: ...
    def restore(self, snapshot: dict[str, Any]) -> None: ...
    def is_terminal(self) -> bool: ...


def adapter_conformance(provider: object | None = None, environment: object | None = None) -> dict:
    report = {"provider": None, "environment": None, "ok": True}
    if provider is not None:
        ok = isinstance(provider, ProviderAdapter)
        report["provider"] = {"ok": ok, "name": getattr(provider, "name", None), "model_revision": getattr(provider, "model_revision", None)}
        report["ok"] = report["ok"] and ok
    if environment is not None:
        ok = isinstance(environment, StatefulEnvironmentAdapter)
        report["environment"] = {"ok": ok, "name": getattr(environment, "name", None), "version": getattr(environment, "version", None)}
        report["ok"] = report["ok"] and ok
    return report
