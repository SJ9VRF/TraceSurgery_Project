from __future__ import annotations

"""Scientific-evidence gate and provenance verification.

Validation/demo runs are rejected as evidence for scientific performance
claims. External records can additionally be checked against their manifest
bytes, preventing a merely populated hash field from counting as provenance.
"""

from pathlib import Path
from typing import Literal
import hashlib
import json
from pydantic import BaseModel, Field


class EvidenceRecord(BaseModel):
    schema_version: str = "1.1"
    run_id: str
    study_id: str
    task_id: str
    model_id: str
    model_revision: str | None = None
    environment_id: str
    benchmark: str
    benchmark_version: str | None = None
    seed: int
    success: bool
    source: Literal["external_execution", "local_validation", "synthetic_demo"]
    trace_path: str | None = None
    manifest_path: str | None = None
    manifest_sha256: str | None = None
    grader_version: str | None = None
    replay_admissible: bool | None = None
    human_audited: bool = False
    recovery_auc: float | None = Field(default=None, ge=0.0, le=1.0)
    diagnosis_faithful: bool | None = None
    point_of_no_return: int | None = Field(default=None, ge=0)
    cost_usd: float | None = Field(default=None, ge=0.0)
    latency_ms: int | None = Field(default=None, ge=0)
    metadata: dict = Field(default_factory=dict)


def read_evidence(path: str | Path) -> list[EvidenceRecord]:
    return [EvidenceRecord.model_validate_json(line) for line in Path(path).read_text().splitlines() if line.strip()]


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def evidence_audit(records: list[EvidenceRecord], *, base_dir: str | Path | None = None, verify_files: bool = False) -> dict:
    errors: list[dict] = []
    warnings: list[dict] = []
    seen: set[str] = set()
    eligible: list[str] = []
    base = Path(base_dir) if base_dir is not None else None
    for r in records:
        reasons = []
        if r.run_id in seen:
            reasons.append("duplicate_run_id")
        seen.add(r.run_id)
        if r.source != "external_execution":
            reasons.append("non_external_source")
        if r.environment_id.lower() in {"local", "localsandbox", "validation"}:
            reasons.append("local_environment")
        if not r.model_revision:
            reasons.append("missing_model_revision")
        if not r.benchmark_version:
            reasons.append("missing_benchmark_version")
        if not r.manifest_path or not r.manifest_sha256:
            reasons.append("missing_manifest_provenance")
        if not r.grader_version:
            reasons.append("missing_grader_version")
        if verify_files and r.manifest_path and r.manifest_sha256:
            mp = Path(r.manifest_path)
            if not mp.is_absolute() and base is not None:
                mp = base / mp
            if not mp.exists():
                reasons.append("manifest_missing_on_disk")
            elif sha256_file(mp) != r.manifest_sha256:
                reasons.append("manifest_hash_mismatch")
        if reasons:
            errors.append({"run_id": r.run_id, "reasons": reasons})
        else:
            eligible.append(r.run_id)
        if r.replay_admissible is False:
            warnings.append({"run_id": r.run_id, "reason": "replay_inadmissible_for_causal_metrics"})
        if r.source == "external_execution" and r.replay_admissible is None:
            warnings.append({"run_id": r.run_id, "reason": "replay_admissibility_unreported"})
    return {
        "ok": not errors,
        "n_records": len(records),
        "n_eligible_for_performance_claims": len(eligible),
        "eligible_run_ids": eligible,
        "files_verified": bool(verify_files),
        "errors": errors,
        "warnings": warnings,
    }


def write_evidence(path: str | Path, records: list[EvidenceRecord]) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w") as f:
        for r in records:
            f.write(r.model_dump_json() + "\n")
    return p
