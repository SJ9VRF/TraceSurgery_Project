from __future__ import annotations

import json, os, platform, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
from pydantic import BaseModel, Field
from tracesurgery.provenance import stable_hash


class ExperimentManifest(BaseModel):
    schema_version: str = "1.0"
    created_at_utc: str
    project_version: str
    command: list[str] = Field(default_factory=list)
    python_version: str
    platform: str
    git_commit: str | None = None
    git_dirty: bool | None = None
    suite_path: str | None = None
    suite_sha256: str | None = None
    task_count: int | None = None
    agent: str | None = None
    trials: int | None = None
    environment: str | None = None
    output_path: str | None = None
    env_presence: dict[str, bool] = Field(default_factory=dict)
    notes: dict = Field(default_factory=dict)


def _git(args: list[str]) -> str | None:
    try:
        return subprocess.check_output(["git", *args], stderr=subprocess.DEVNULL, text=True).strip()
    except Exception:
        return None


def file_sha256(path: str | Path) -> str:
    import hashlib
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def make_manifest(*, project_version: str, suite_path: str | None = None,
                  task_count: int | None = None, agent: str | None = None,
                  trials: int | None = None, environment: str | None = None,
                  output_path: str | None = None, notes: dict | None = None) -> ExperimentManifest:
    commit = _git(["rev-parse", "HEAD"])
    status = _git(["status", "--porcelain"])
    env_keys = ["OPENAI_API_KEY", "ANTHROPIC_API_KEY", "TRACE_SURGERY_RUN_ID"]
    return ExperimentManifest(
        created_at_utc=datetime.now(timezone.utc).isoformat(),
        project_version=project_version,
        command=list(sys.argv),
        python_version=platform.python_version(),
        platform=platform.platform(),
        git_commit=commit,
        git_dirty=(bool(status) if status is not None else None),
        suite_path=suite_path,
        suite_sha256=(file_sha256(suite_path) if suite_path and Path(suite_path).exists() else None),
        task_count=task_count,
        agent=agent,
        trials=trials,
        environment=environment,
        output_path=output_path,
        env_presence={k: bool(os.environ.get(k)) for k in env_keys},
        notes=notes or {},
    )


def write_manifest(path: str | Path, manifest: ExperimentManifest) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(manifest.model_dump(), indent=2, sort_keys=True) + "\n")
    return p


def manifest_fingerprint(manifest: ExperimentManifest) -> str:
    return stable_hash(manifest.model_dump(exclude={"created_at_utc"}))
