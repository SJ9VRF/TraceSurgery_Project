from __future__ import annotations
from pathlib import Path
import json, yaml
from tracesurgery.core.models import Task, TrialResult

def load_task(path):
    p = Path(path)
    data = yaml.safe_load(p.read_text()) if p.suffix in {".yaml", ".yml"} else json.loads(p.read_text())
    return Task.model_validate(data)

def load_suite(path):
    p = Path(path)
    data = yaml.safe_load(p.read_text())
    base = p.parent
    tasks = []
    for x in data["tasks"]:
        xp = Path(x)
        tasks.append(load_task(xp if xp.is_absolute() else base / xp))
    return tasks

def write_results(path, results: list[TrialResult]):
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w") as f:
        for r in results: f.write(r.model_dump_json()+"\n")

def read_results(path):
    return [TrialResult.model_validate_json(line) for line in Path(path).read_text().splitlines() if line.strip()]
