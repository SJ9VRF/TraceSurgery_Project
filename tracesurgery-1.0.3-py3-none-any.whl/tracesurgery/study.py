from __future__ import annotations

"""External-study planning and concurrency-safe resumable run ledger.

The core does not call frontier models directly. It creates a deterministic,
auditable matrix of runs that provider/environment adapters can execute. The
ledger is atomic, resume-friendly, and safe for multiple local workers.
"""

from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal
import hashlib
import json
import os
import time

import yaml
from pydantic import BaseModel, Field, model_validator


class ModelSpec(BaseModel):
    id: str
    provider: str
    model: str
    adapter: str
    notes: dict = Field(default_factory=dict)


class EnvironmentSpec(BaseModel):
    id: str
    adapter: str
    benchmark: str
    version: str | None = None
    notes: dict = Field(default_factory=dict)


class StudySpec(BaseModel):
    schema_version: str = "1.0"
    study_id: str
    task_ids: list[str]
    models: list[ModelSpec]
    environments: list[EnvironmentSpec]
    seeds: list[int] = Field(default_factory=lambda: [0])
    repetitions: int = Field(default=1, ge=1)
    preregistration: str | None = None
    notes: dict = Field(default_factory=dict)

    @model_validator(mode="after")
    def validate_unique(self):
        for label, xs in (("model", [x.id for x in self.models]), ("environment", [x.id for x in self.environments]), ("task", self.task_ids)):
            if len(xs) != len(set(xs)):
                raise ValueError(f"duplicate {label} ids")
        if not self.task_ids or not self.models or not self.environments:
            raise ValueError("study requires tasks, models, and environments")
        return self


RunStatus = Literal["pending", "running", "complete", "failed", "invalid"]


class RunEntry(BaseModel):
    schema_version: str = "1.0"
    run_id: str
    study_id: str
    task_id: str
    model_id: str
    environment_id: str
    seed: int
    repetition: int
    status: RunStatus = "pending"
    attempt: int = 0
    worker_id: str | None = None
    result_path: str | None = None
    error: str | None = None
    updated_at_utc: str


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _run_id(study_id: str, task_id: str, model_id: str, environment_id: str, seed: int, repetition: int) -> str:
    raw = f"{study_id}|{task_id}|{model_id}|{environment_id}|{seed}|{repetition}".encode()
    return hashlib.sha256(raw).hexdigest()[:20]


def load_study(path: str | Path) -> StudySpec:
    data = yaml.safe_load(Path(path).read_text())
    return StudySpec.model_validate(data)


def expand_study(spec: StudySpec) -> list[RunEntry]:
    rows: list[RunEntry] = []
    for env in spec.environments:
        for model in spec.models:
            for task_id in spec.task_ids:
                for seed in spec.seeds:
                    for rep in range(spec.repetitions):
                        rows.append(RunEntry(
                            run_id=_run_id(spec.study_id, task_id, model.id, env.id, seed, rep),
                            study_id=spec.study_id,
                            task_id=task_id,
                            model_id=model.id,
                            environment_id=env.id,
                            seed=seed,
                            repetition=rep,
                            updated_at_utc=_now(),
                        ))
    return rows


class LedgerLockTimeout(RuntimeError):
    pass


class RunLedger:
    """JSONL ledger with atomic writes and a dependency-free directory lock."""

    def __init__(self, path: str | Path, *, lock_timeout_s: float = 10.0):
        self.path = Path(path)
        self.lock_path = Path(str(self.path) + ".lock")
        self.lock_timeout_s = lock_timeout_s

    @contextmanager
    def _lock(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        deadline = time.monotonic() + self.lock_timeout_s
        while True:
            try:
                os.mkdir(self.lock_path)
                break
            except FileExistsError:
                if time.monotonic() >= deadline:
                    raise LedgerLockTimeout(f"timed out acquiring ledger lock: {self.lock_path}")
                time.sleep(0.02)
        try:
            yield
        finally:
            try:
                os.rmdir(self.lock_path)
            except FileNotFoundError:
                pass

    def initialize(self, spec: StudySpec, *, overwrite: bool = False) -> list[RunEntry]:
        with self._lock():
            if self.path.exists() and not overwrite:
                raise FileExistsError(self.path)
            rows = expand_study(spec)
            self._write_unlocked(rows)
            return rows

    def _read_unlocked(self) -> list[RunEntry]:
        if not self.path.exists():
            return []
        return [RunEntry.model_validate_json(line) for line in self.path.read_text().splitlines() if line.strip()]

    def read(self) -> list[RunEntry]:
        with self._lock():
            return self._read_unlocked()

    def _write_unlocked(self, rows: list[RunEntry]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        with tmp.open("w") as f:
            for row in rows:
                f.write(row.model_dump_json() + "\n")
            f.flush()
            os.fsync(f.fileno())
        tmp.replace(self.path)

    def update(self, run_id: str, **fields) -> RunEntry:
        with self._lock():
            rows = self._read_unlocked()
            found = None
            new_rows = []
            for row in rows:
                if row.run_id == run_id:
                    payload = row.model_dump()
                    payload.update(fields)
                    payload["updated_at_utc"] = _now()
                    found = RunEntry.model_validate(payload)
                    row = found
                new_rows.append(row)
            if found is None:
                raise KeyError(run_id)
            self._write_unlocked(new_rows)
            return found

    def claim_next(self, *, worker_id: str | None = None, retry_failed: bool = True) -> RunEntry | None:
        """Atomically claim one run. Multiple workers cannot claim the same cell."""
        eligible = {"pending", "failed"} if retry_failed else {"pending"}
        with self._lock():
            rows = self._read_unlocked()
            for i, row in enumerate(rows):
                if row.status in eligible:
                    payload = row.model_dump()
                    payload.update(status="running", attempt=row.attempt + 1, error=None, worker_id=worker_id, updated_at_utc=_now())
                    claimed = RunEntry.model_validate(payload)
                    rows[i] = claimed
                    self._write_unlocked(rows)
                    return claimed
            return None

    def mark_complete(self, run_id: str, result_path: str) -> RunEntry:
        return self.update(run_id, status="complete", result_path=result_path, error=None)

    def mark_failed(self, run_id: str, error: str) -> RunEntry:
        return self.update(run_id, status="failed", error=error)

    def summary(self) -> dict:
        rows = self.read()
        counts: dict[str, int] = {}
        for row in rows:
            counts[row.status] = counts.get(row.status, 0) + 1
        return {"n_runs": len(rows), "status": dict(sorted(counts.items())), "complete_fraction": (counts.get("complete", 0) / len(rows) if rows else 0.0)}


def write_study_snapshot(path: str | Path, spec: StudySpec) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(spec.model_dump(), indent=2, sort_keys=True) + "\n")
    return p
