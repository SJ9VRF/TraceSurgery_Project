from __future__ import annotations
import networkx as nx
from tracesurgery.core.models import FailureEvent, CausalEdge

class CausalFailureGraph:
    def __init__(self, events: list[FailureEvent], edges: list[CausalEdge] | None = None):
        self.events={e.id:e for e in events}
        self.edges=edges or []
        self.graph=nx.DiGraph()
        for e in events: self.graph.add_node(e.id, event=e)
        for edge in self.edges: self.graph.add_edge(edge.source, edge.target, relation=edge.relation)
    def root_failures(self):
        marked=[e.id for e in self.events.values() if e.root_cause]
        if marked: return marked
        return [n for n in self.graph.nodes if self.graph.in_degree(n)==0]
    def cascade_size(self, event_id: str):
        return len(nx.descendants(self.graph, event_id))
    def propagation_depth(self, event_id: str):
        if event_id not in self.graph: return 0
        lengths=nx.single_source_shortest_path_length(self.graph, event_id)
        return max(lengths.values(), default=0)
