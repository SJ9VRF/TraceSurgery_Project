from __future__ import annotations
from tracesurgery.core.models import FailureEvent, FailureType, Recoverability, StepRecord, CausalEdge
from tracesurgery.core.utils import get_path

RECOVERY_ACTIONS={'set','copy','append'}

def infer_failures(trajectory:list[StepRecord], task_success:bool|None=None)->tuple[list[FailureEvent],list[CausalEdge],int|None]:
    """Objective trace detector only. It does *not* label interventions as agent
    failures and does not claim semantic root-cause attribution. Candidate causal
    edges are temporal/observable hypotheses for later human or calibrated-model
    adjudication.
    """
    failures=[]; edges=[]; recent=None; repeated=0
    def add(step,typ,desc,rec,root=False,confidence=1.0,evidence=None,attribution='agent'):
        e=FailureEvent(id=f'F{len(failures)+1}',step=step,type=typ,description=desc,confidence=confidence,
            root_cause=root,recoverability=rec,recovery_window_start=step,
            recovery_window_end=step+(2 if rec in {Recoverability.R1,Recoverability.R2} else 5),
            evidence=evidence or {},attribution=attribution); failures.append(e); return e
    for r in trajectory:
        # Invalid tool/action: objective execution failure.
        before_n=len(r.environment_state_before.get('events',[])); after_events=r.environment_state_after.get('events',[])[before_n:]
        if any(e.get('type')=='invalid_tool' for e in after_events):
            add(r.step,FailureType.execution_invalid,'Environment rejected an unknown or malformed action',Recoverability.R1,
                root=not failures,evidence={'tool':r.action.tool})
        sig=(r.action.tool,repr(sorted(r.action.args.items())))
        repeated = repeated+1 if sig==recent and r.action.tool!='finish' else 0; recent=sig
        if repeated>=1:
            e=add(r.step,FailureType.recovery_repeat,'Repeated identical action without observed progress',Recoverability.R1,
                confidence=.9,evidence={'action':r.action.model_dump()})
            if len(failures)>1: edges.append(CausalEdge(source=failures[-2].id,target=e.id,relation='contributed',confidence=.5))
        if r.expected_state_after:
            mm=[]
            for path,expected in r.expected_state_after.items():
                actual=get_path(r.environment_state_after,path)
                if actual!=expected: mm.append({'path':path,'expected':expected,'actual':actual})
            if mm:
                e=add(r.step,FailureType.verification_state,'Expected post-action state did not materialize',Recoverability.R2,
                    root=not failures,evidence={'mismatches':mm})
                if len(failures)>1: edges.append(CausalEdge(source=failures[-2].id,target=e.id,relation='contributed',confidence=.4))
        if r.belief_mismatches:
            e=add(r.step,FailureType.state_assumption,'Agent-reported belief diverged from environment state',Recoverability.R2,
                root=not failures,evidence={'mismatches':r.belief_mismatches})
            if len(failures)>1: edges.append(CausalEdge(source=failures[-2].id,target=e.id,relation='contributed',confidence=.4))
        if r.action.completion_claim and task_success is False:
            e=add(r.step,FailureType.verification_false_positive,'Agent claimed completion but state-based grader did not confirm success',Recoverability.R3,
                root=not failures,evidence={'completion_claim':True})
            if len(failures)>1: edges.append(CausalEdge(source=failures[-2].id,target=e.id,relation='contributed',confidence=.6))
        if r.blocked:
            add(r.step,FailureType.safety_irreversible,'High-risk action was blocked by configured execution policy',Recoverability.R6,
                root=not failures,evidence={'action':r.action.model_dump()})
    # Conservative recovery evidence: state-changing corrective action inside window.
    failure_steps={f.step for f in failures}
    for f in failures:
        if f.recoverability in {Recoverability.R1,Recoverability.R2,Recoverability.R3,Recoverability.R4,Recoverability.R5}:
            for r in trajectory:
                if not (f.step<r.step<=(f.recovery_window_end or f.step)): continue
                if r.action.tool in RECOVERY_ACTIONS and r.state_delta and r.step not in failure_steps:
                    f.recovered_at_step=r.step; break
    # Detection latency is only known when the agent explicitly exposes a signal.
    # Never set detected_at_step=failure step by fiat.
    unrecovered=[f for f in failures if f.recoverability not in {None,Recoverability.R0,Recoverability.R7} and f.recovered_at_step is None]
    ponr=None
    if unrecovered and trajectory:
        ponr=min(min((f.recovery_window_end or f.step)+1 for f in unrecovered),trajectory[-1].step)
    return failures,edges,ponr
