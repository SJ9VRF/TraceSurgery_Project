from __future__ import annotations
import importlib.util, json, platform, sys
from pathlib import Path
from tracesurgery import __version__


def run_doctor(repo_root: str | Path = ".") -> dict:
    root = Path(repo_root).resolve()
    checks = {
        "python_supported": sys.version_info >= (3,10),
        "package_importable": importlib.util.find_spec("tracesurgery") is not None,
        "pytest_available": importlib.util.find_spec("pytest") is not None,
        "ruff_available": importlib.util.find_spec("ruff") is not None,
        "validation_suite_present": (root / "tasks/suites/validation_500.yaml").exists(),
        "paper_present": (root / "paper/main.pdf").exists(),
        "novelty_audit_present": (root / "docs/NOVELTY_AUDIT_2026-09.md").exists(),
        "counterfactual_protocol_present": (root / "docs/COUNTERFACTUAL_PROTOCOL.md").exists(),
        "schema_policy_present": (root / "docs/SCHEMA_COMPATIBILITY.md").exists(),
        "v1_release_notes_present": (root / "docs/V1_RELEASE_NOTES.md").exists(),
    }
    required = ["python_supported", "package_importable", "validation_suite_present", "novelty_audit_present", "counterfactual_protocol_present"]
    return {
        "ok": all(checks[k] for k in required),
        "version": __version__,
        "python": platform.python_version(),
        "repo_root": str(root),
        "checks": checks,
        "note": "ruff/pytest are development-tool checks; absence is reported, not disguised as success.",
    }
