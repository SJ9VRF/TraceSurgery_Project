from __future__ import annotations
import argparse, json
from pathlib import Path
from collections import Counter
from tracesurgery.io import load_suite, load_task, write_results
from tracesurgery.environments.local import LocalSandbox
from tracesurgery.agents.scripted import ScriptedAgent, FaultyScriptedAgent
from tracesurgery.agents.baselines import RepeatingFailureAgent, UnsafeDiagnosticAgent
from tracesurgery.runners.runner import TrialRunner
from tracesurgery.analysis import summarize
from tracesurgery.perturbations.library import REGISTRY
from tracesurgery.task_lint import lint_suite
from tracesurgery.counterfactual import CounterfactualSurgeon, SurgeryKind
from tracesurgery.registry import make_manifest, write_manifest, manifest_fingerprint
from tracesurgery.doctor import run_doctor
from tracesurgery.release_audit import audit as release_audit
from tracesurgery import __version__
from tracesurgery.study import load_study, RunLedger, write_study_snapshot
from tracesurgery.evidence import read_evidence, evidence_audit
from tracesurgery.scientific_report import write_report as write_scientific_report

AGENTS = {
    "scripted": ScriptedAgent,
    "faulty": FaultyScriptedAgent,
    "repeating-failure": RepeatingFailureAgent,
    "unsafe-diagnostic": UnsafeDiagnosticAgent,
}

def _perturbations(names, step):
    return [REGISTRY[n](step=step) for n in names]

def main():
    p=argparse.ArgumentParser(prog="tracesurgery")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub=p.add_subparsers(dest="cmd", required=True)

    r=sub.add_parser("run")
    r.add_argument("--suite", required=True)
    r.add_argument("--agent", choices=sorted(AGENTS), default="scripted")
    r.add_argument("--trials", type=int, default=1)
    r.add_argument("--output", required=True)
    r.add_argument("--perturbation", action="append", choices=sorted(REGISTRY), default=[])
    r.add_argument("--perturb-at", type=int, default=1)

    a=sub.add_parser("analyze")
    a.add_argument("results")
    a.add_argument("--output", required=True)
    a.add_argument("--bootstrap-seed", type=int, default=0)

    v=sub.add_parser("validate-suite")
    v.add_argument("--suite", required=True)
    v.add_argument("--oracle-run", action="store_true")

    l=sub.add_parser("lint-suite")
    l.add_argument("--suite", required=True)

    sub.add_parser("list-perturbations")

    sub.add_parser("doctor")

    ra=sub.add_parser("release-audit")
    ra.add_argument("--root", default=".")
    ra.add_argument("--output")

    si=sub.add_parser("study-init")
    si.add_argument("--config", required=True)
    si.add_argument("--output", required=True)
    si.add_argument("--overwrite", action="store_true")

    ss=sub.add_parser("study-status")
    ss.add_argument("--ledger", required=True)

    sc=sub.add_parser("study-claim")
    sc.add_argument("--ledger", required=True)
    sc.add_argument("--worker")
    sc.add_argument("--no-retry-failed", action="store_true")

    sm=sub.add_parser("study-mark")
    sm.add_argument("--ledger", required=True)
    sm.add_argument("--run-id", required=True)
    sm.add_argument("--status", choices=["complete", "failed", "invalid"], required=True)
    sm.add_argument("--result-path")
    sm.add_argument("--error")

    ea=sub.add_parser("evidence-audit")
    ea.add_argument("--records", required=True)
    ea.add_argument("--output")
    ea.add_argument("--verify-files", action="store_true")

    er=sub.add_parser("evidence-report")
    er.add_argument("--records", required=True)
    er.add_argument("--output", required=True)
    er.add_argument("--bootstrap-seed", type=int, default=0)
    er.add_argument("--skip-file-verification", action="store_true")

    srg=sub.add_parser("surgery")
    srg.add_argument("--task", required=True)
    srg.add_argument("--output", required=True)

    args=p.parse_args()
    if args.cmd=="run":
        tasks=load_suite(args.suite)
        agent_cls=AGENTS[args.agent]
        runner=TrialRunner(LocalSandbox())
        results=[]
        for task in tasks:
            for seed in range(args.trials):
                results.append(runner.run(task, agent_cls(), seed, _perturbations(args.perturbation, args.perturb_at)))
        outdir=Path(args.output); out=outdir/"results.jsonl"
        write_results(out, results)
        manifest=make_manifest(project_version=__version__, suite_path=args.suite, task_count=len(tasks), agent=args.agent, trials=args.trials, environment="local", output_path=str(out))
        mp=write_manifest(outdir/"manifest.json", manifest)
        print(json.dumps({"trials":len(results),"results":str(out),"manifest":str(mp),"manifest_fingerprint":manifest_fingerprint(manifest)}, indent=2))
    elif args.cmd=="analyze":
        print(json.dumps(summarize(args.results,args.output,args.bootstrap_seed), indent=2))
    elif args.cmd=="lint-suite":
        report=lint_suite(load_suite(args.suite)); print(json.dumps(report,indent=2)); raise SystemExit(0 if report["valid"] else 2)
    elif args.cmd=="validate-suite":
        tasks=load_suite(args.suite)
        counts=Counter(t.category for t in tasks)
        ids=[t.id for t in tasks]
        report={"n_tasks":len(tasks),"categories":dict(sorted(counts.items())),"duplicate_ids":len(ids)-len(set(ids)),"oracle_failures":[]}
        if args.oracle_run:
            runner=TrialRunner(LocalSandbox())
            for task in tasks:
                result=runner.run(task, ScriptedAgent(), seed=0)
                if not result.success:
                    report["oracle_failures"].append(task.id)
        report["valid"] = report["duplicate_ids"] == 0 and not report["oracle_failures"]
        print(json.dumps(report, indent=2))
        raise SystemExit(0 if report["valid"] else 2)
    elif args.cmd=="doctor":
        report=run_doctor(Path.cwd()); print(json.dumps(report, indent=2)); raise SystemExit(0 if report["ok"] else 2)
    elif args.cmd=="release-audit":
        report=release_audit(Path(args.root))
        if args.output:
            Path(args.output).write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
        print(json.dumps(report, indent=2)); raise SystemExit(0 if report["ok"] else 2)
    elif args.cmd=="study-init":
        spec=load_study(args.config)
        outdir=Path(args.output); outdir.mkdir(parents=True, exist_ok=True)
        ledger=RunLedger(outdir/"ledger.jsonl")
        rows=ledger.initialize(spec, overwrite=args.overwrite)
        snap=write_study_snapshot(outdir/"study.snapshot.json", spec)
        print(json.dumps({"study_id":spec.study_id,"n_runs":len(rows),"ledger":str(ledger.path),"snapshot":str(snap)}, indent=2))
    elif args.cmd=="study-status":
        print(json.dumps(RunLedger(args.ledger).summary(), indent=2))
    elif args.cmd=="study-claim":
        row=RunLedger(args.ledger).claim_next(worker_id=args.worker, retry_failed=not args.no_retry_failed)
        print(json.dumps(None if row is None else row.model_dump(), indent=2))
    elif args.cmd=="study-mark":
        ledger=RunLedger(args.ledger)
        if args.status=="complete":
            if not args.result_path:
                raise SystemExit("--result-path is required for complete")
            row=ledger.mark_complete(args.run_id,args.result_path)
        elif args.status=="failed":
            row=ledger.mark_failed(args.run_id,args.error or "unspecified failure")
        else:
            row=ledger.update(args.run_id,status="invalid",error=args.error)
        print(json.dumps(row.model_dump(), indent=2))
    elif args.cmd=="evidence-audit":
        report=evidence_audit(read_evidence(args.records), base_dir=Path(args.records).parent, verify_files=args.verify_files)
        if args.output:
            Path(args.output).write_text(json.dumps(report, indent=2, sort_keys=True)+"\n")
        print(json.dumps(report, indent=2)); raise SystemExit(0 if report["ok"] else 2)
    elif args.cmd=="evidence-report":
        report=write_scientific_report(args.records,args.output,bootstrap_seed=args.bootstrap_seed,verify_files=not args.skip_file_verification)
        print(json.dumps({"ok":True,"output_dir":report["output_dir"],"n_records":report["summary"]["n_records"]},indent=2))
    elif args.cmd=="surgery":
        task=load_task(args.task)
        runner=TrialRunner(LocalSandbox())
        oracle=runner.run(task, ScriptedAgent(), seed=0)
        failed=runner.run(task, FaultyScriptedAgent(), seed=0)
        if failed.success:
            raise SystemExit("task's configured fault did not produce a failed trajectory")
        surface=CounterfactualSurgeon(LocalSandbox()).sweep(task,failed,oracle)
        out=Path(args.output); out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(surface.to_dict(),indent=2))
        print(json.dumps({"task":task.id,"baseline_success":failed.success,"oracle_success":oracle.success,"output":str(out),"summary":surface.to_dict()["summary"]},indent=2))
    else:
        print("\n".join(sorted(REGISTRY)))

if __name__ == "__main__": main()
