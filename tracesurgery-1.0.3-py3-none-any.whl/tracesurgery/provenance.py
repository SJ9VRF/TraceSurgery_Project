from __future__ import annotations

"""Stable hashes and provenance helpers for auditable branch experiments."""

import hashlib
import json
from typing import Any


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def stable_hash(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def action_hashes(actions) -> list[str]:
    return [stable_hash(a.model_dump() if hasattr(a, "model_dump") else a) for a in actions]
