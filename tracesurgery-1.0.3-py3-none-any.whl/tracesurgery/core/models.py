from __future__ import annotations
from enum import Enum
from typing import Any, Literal
from pydantic import BaseModel, Field, model_validator

class RiskLevel(str, Enum):
    safe='safe'; moderate='moderate'; high='high'

class Recoverability(str, Enum):
    R0='R0_no_intervention'; R1='R1_local_correction'; R2='R2_local_reconstruction'
    R3='R3_subgoal_replan'; R4='R4_global_replan'; R5='R5_rollback_required'
    R6='R6_human_clarification'; R7='R7_irrecoverable'

class FailureType(str, Enum):
    grounding_element='grounding.element_misidentification'; grounding_text='grounding.text_misread'
    grounding_spatial='grounding.spatial_error'; grounding_hidden='grounding.occluded_state_missed'
    state_stale='state.stale_state'; state_hidden='state.hidden_state_error'; state_assumption='state.incorrect_state_assumption'
    state_lost='state.lost_intermediate_state'; state_transition='state.state_transition_missed'
    planning_decomposition='planning.decomposition_error'; planning_ordering='planning.ordering_error'
    planning_prerequisite='planning.missing_prerequisite'; planning_commitment='planning.premature_commitment'; planning_infeasible='planning.infeasible_plan'
    memory_forgotten='memory.forgotten_fact'; memory_retrieval='memory.incorrect_retrieval'; memory_source_confusion='memory.source_confusion'; memory_pollution='memory.context_pollution'
    execution_wrong_click='execution.wrong_click'; execution_wrong_text='execution.wrong_text'; execution_wrong_target='execution.wrong_target'
    execution_invalid='execution.malformed_action'; execution_duplicate='execution.duplicate_action'
    verification_false_positive='verification.completion_false_positive'; verification_missed='verification.failure_not_detected'
    verification_partial='verification.partial_success_misclassified'; verification_state='verification.state_not_verified'
    recovery_repeat='recovery.repeated_failed_action'; recovery_incorrect='recovery.incorrect_repair'; recovery_restart='recovery.unnecessary_restart'
    recovery_replan='recovery.failed_replan'; recovery_new_failure='recovery.recovery_created_new_failure'
    safety_side_effect='safety.unintended_side_effect'; safety_irreversible='safety.irreversible_action'
    safety_privilege='safety.privilege_violation'; safety_constraint='safety.constraint_violation'

class AssertionSpec(BaseModel):
    type: str; path: str | None=None; equals: Any=None; contains: Any=None; value: Any=None
    weight: float=Field(default=1.0, gt=0)

class Task(BaseModel):
    id: str; instruction: str; environment: str='local'; category: str='general'
    applications: list[str]=Field(default_factory=list); initial_state: dict[str,Any]=Field(default_factory=dict)
    goal_state: dict[str,Any]=Field(default_factory=dict); success_assertions: list[AssertionSpec]=Field(default_factory=list)
    safety_constraints: list[AssertionSpec]=Field(default_factory=list); max_steps: int=Field(default=40, ge=1)
    expected_subgoals: list[str]=Field(default_factory=list); risk_level: RiskLevel=RiskLevel.safe
    horizon: int=Field(default=1,ge=1,le=5); statefulness: int=Field(default=1,ge=1,le=5); recovery_complexity: int=Field(default=1,ge=1,le=5)
    metadata: dict[str,Any]=Field(default_factory=dict)
    @model_validator(mode='after')
    def check_task(self):
        if not self.success_assertions: raise ValueError('task must define at least one success assertion')
        return self

class Action(BaseModel):
    tool: str; args: dict[str,Any]=Field(default_factory=dict); rationale: str|None=None
    expected_state_after: dict[str,Any]=Field(default_factory=dict)
    belief_state: dict[str,Any]=Field(default_factory=dict)
    completion_claim: bool=False
    confidence: float|None=Field(default=None, ge=0, le=1)

class Observation(BaseModel):
    visible_state: dict[str,Any]=Field(default_factory=dict); message: str=''; uncertainty: list[str]=Field(default_factory=list)

class InterventionEvent(BaseModel):
    id: str; step: int=Field(ge=0); name: str; kind: Literal['exogenous','fault_injection']='fault_injection'
    metadata: dict[str,Any]=Field(default_factory=dict)

class FailureEvent(BaseModel):
    id: str; step: int=Field(ge=0); type: FailureType; description: str=''; confidence: float=Field(default=1.0,ge=0,le=1)
    root_cause: bool=False; recoverability: Recoverability|None=None; recovery_window_start: int|None=None; recovery_window_end: int|None=None
    detected_at_step: int|None=None; recovered_at_step: int|None=None; evidence: dict[str,Any]=Field(default_factory=dict)
    attribution: Literal['agent','environment','ambiguous']='agent'

class CausalEdge(BaseModel):
    source: str; target: str; relation: Literal['caused','contributed','masked']='caused'; confidence: float=Field(default=1.0,ge=0,le=1)

class StepRecord(BaseModel):
    step: int
    observation: Observation                       # pre-action observation (what the agent actually saw)
    action: Action
    post_observation: Observation|None=None         # observation returned after action
    environment_state_before: dict[str,Any]
    expected_state_after: dict[str,Any]=Field(default_factory=dict)
    environment_state_after: dict[str,Any]
    state_delta: dict[str,Any]=Field(default_factory=dict)
    belief_mismatches: list[dict[str,Any]]=Field(default_factory=list)
    failure_event: FailureEvent|None=None
    interventions: list[InterventionEvent]=Field(default_factory=list)
    perturbations_applied: list[str]=Field(default_factory=list)  # compatibility
    risk: RiskLevel=RiskLevel.safe; blocked: bool=False
    latency_ms: int=0; cost_usd: float=0.0

class TrialResult(BaseModel):
    task_id: str; trial_id: str; agent: str; model: str; seed: int; trajectory: list[StepRecord]
    final_state: dict[str,Any]; grader_results: dict[str,Any]
    failure_events: list[FailureEvent]=Field(default_factory=list); interventions: list[InterventionEvent]=Field(default_factory=list)
    causal_edges: list[CausalEdge]=Field(default_factory=list); root_failures: list[str]=Field(default_factory=list); point_of_no_return: int|None=None
    success: bool; cost_usd: float=0.0; latency_ms: int=0; metadata: dict[str,Any]=Field(default_factory=dict)
