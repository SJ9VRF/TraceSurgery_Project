from __future__ import annotations
import copy
from typing import Any

def deep_copy(x):
    return copy.deepcopy(x)

def get_path(obj: Any, path: str | None, default=None):
    if path in (None, ""):
        return obj
    cur = obj
    for part in str(path).split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        elif isinstance(cur, list) and part.isdigit() and int(part) < len(cur):
            cur = cur[int(part)]
        else:
            return default
    return cur

def set_path(obj: dict, path: str, value: Any):
    parts = path.split(".")
    cur = obj
    for p in parts[:-1]:
        if p not in cur or not isinstance(cur[p], dict):
            cur[p] = {}
        cur = cur[p]
    cur[parts[-1]] = deep_copy(value)

def delete_path(obj: dict, path: str):
    parts = path.split(".")
    cur = obj
    for p in parts[:-1]:
        if not isinstance(cur, dict) or p not in cur:
            return
        cur = cur[p]
    if isinstance(cur, dict):
        cur.pop(parts[-1], None)

def project_state(state: dict, visible_paths: list[str] | None = None) -> dict:
    """Return agent-visible state without benchmark/private keys.

    If visible_paths are supplied, only those paths are exposed. Otherwise all
    top-level keys except keys beginning with '_' and the internal event log are
    visible. This prevents accidental ground-truth leakage in local tests.
    """
    if visible_paths:
        out = {}
        for path in visible_paths:
            value = get_path(state, path, default=None)
            if value is not None:
                set_path(out, path, value)
        return out
    return {k: deep_copy(v) for k, v in state.items() if not k.startswith("_") and k != "events"}

def state_diff(before: Any, after: Any, prefix: str = "") -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    if isinstance(before, dict) and isinstance(after, dict):
        for key in sorted(set(before) | set(after)):
            path = f"{prefix}.{key}" if prefix else str(key)
            if key not in before:
                out[path] = {"before": None, "after": deep_copy(after[key])}
            elif key not in after:
                out[path] = {"before": deep_copy(before[key]), "after": None}
            else:
                out.update(state_diff(before[key], after[key], path))
    elif before != after:
        out[prefix] = {"before": deep_copy(before), "after": deep_copy(after)}
    return out
