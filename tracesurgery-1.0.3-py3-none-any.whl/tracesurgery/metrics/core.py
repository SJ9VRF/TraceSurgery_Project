from __future__ import annotations
from tracesurgery.core.models import TrialResult, Recoverability
from tracesurgery.failures.causal_graph import CausalFailureGraph

def trial_metrics(trial: TrialResult) -> dict:
    failures = trial.failure_events
    graph = CausalFailureGraph(failures, trial.causal_edges)
    first = min((f.step for f in failures), default=None)
    horizon = max(len(trial.trajectory), 1)
    recoverable = [f for f in failures if f.recoverability not in (None, Recoverability.R0, Recoverability.R7)]
    recovered = [f for f in recoverable if f.recovered_at_step is not None]
    roots = graph.root_failures() if failures else []
    depths = [graph.propagation_depth(r) for r in roots]
    cascades = [graph.cascade_size(r) for r in roots]
    detection_latencies = [f.detected_at_step - f.step for f in failures if f.detected_at_step is not None]
    recovery_cost_steps = [f.recovered_at_step - f.step for f in recovered if f.recovered_at_step is not None]
    high_risk = [s for s in trial.trajectory if s.risk.value == "high"]
    blocked = [s for s in trial.trajectory if s.blocked]
    return {
        "task_success": float(trial.success),
        "first_failure_position": None if first is None else first / horizon,
        "failure_count": len(failures),
        "recoverable_failure_count": len(recoverable),
        "recovered_failure_count": len(recovered),
        "recovery_rate": None if not recoverable else len(recovered) / len(recoverable),
        "mean_recovery_steps": None if not recovery_cost_steps else sum(recovery_cost_steps) / len(recovery_cost_steps),
        "mean_failure_detection_latency": None if not detection_latencies else sum(detection_latencies) / len(detection_latencies),
        "root_failure_count": len(roots),
        "max_error_propagation_depth": max(depths, default=0),
        "max_failure_cascade_size": max(cascades, default=0),
        "point_of_no_return": trial.point_of_no_return,
        "high_risk_action_count": len(high_risk),
        "blocked_high_risk_action_count": len(blocked),
        "cost_usd": trial.cost_usd,
        "latency_ms": trial.latency_ms,
    }
