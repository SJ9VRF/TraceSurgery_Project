from __future__ import annotations

"""Guarded scientific aggregation for external evidence.

This module refuses to summarize a mixed/invalid evidence file. It creates
machine-readable and paper-ready artifacts only after the scientific-evidence
gate passes.
"""

from collections import defaultdict
from pathlib import Path
import csv
import json

from tracesurgery.evidence import EvidenceRecord, evidence_audit, read_evidence
from tracesurgery.statistics import task_cluster_bootstrap, paired_task_bootstrap, wilson_interval

OPTIONAL_METRICS = ["recovery_auc", "diagnosis_faithful", "point_of_no_return", "cost_usd", "latency_ms"]


def _rows(records: list[EvidenceRecord], model_id: str) -> list[dict]:
    out = []
    for r in records:
        if r.model_id != model_id:
            continue
        row = {"task_id": r.task_id, "task_success": float(r.success)}
        for m in OPTIONAL_METRICS:
            v = getattr(r, m)
            if isinstance(v, bool):
                v = float(v)
            row[m] = v
        out.append(row)
    return out


def summarize_records(records: list[EvidenceRecord], *, bootstrap_seed: int = 0) -> dict:
    models = sorted({r.model_id for r in records})
    report = {"n_records": len(records), "n_tasks": len({r.task_id for r in records}), "models": {}, "paired_success_deltas": {}}
    for model in models:
        rs = [r for r in records if r.model_id == model]
        rows = _rows(records, model)
        successes = sum(r.success for r in rs)
        lo, hi = wilson_interval(successes, len(rs))
        metrics = {"task_success": task_cluster_bootstrap(rows, "task_success", seed=bootstrap_seed)}
        for m in OPTIONAL_METRICS:
            if any(row.get(m) is not None for row in rows):
                metrics[m] = task_cluster_bootstrap(rows, m, seed=bootstrap_seed)
        report["models"][model] = {
            "n_records": len(rs),
            "n_tasks": len({r.task_id for r in rs}),
            "trial_success_wilson": {"rate": successes / len(rs) if rs else None, "ci95": [lo, hi] if rs else [None, None]},
            "metrics": metrics,
            "replay_admissible_fraction": (sum(r.replay_admissible is True for r in rs) / len(rs)) if rs else None,
            "human_audited_fraction": (sum(r.human_audited for r in rs) / len(rs)) if rs else None,
        }
    for i, a in enumerate(models):
        for b in models[i + 1:]:
            delta = paired_task_bootstrap(_rows(records, a), _rows(records, b), "task_success", seed=bootstrap_seed)
            report["paired_success_deltas"][f"{b}-minus-{a}"] = delta
    return report


def _fmt(x: float | None, digits: int = 3) -> str:
    return "—" if x is None else f"{x:.{digits}f}"


def write_report(records_path: str | Path, output_dir: str | Path, *, bootstrap_seed: int = 0, verify_files: bool = True) -> dict:
    rp = Path(records_path)
    records = read_evidence(rp)
    audit = evidence_audit(records, base_dir=rp.parent, verify_files=verify_files)
    if not audit["ok"]:
        raise ValueError("scientific evidence audit failed; refusing to generate paper artifacts")
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    summary = summarize_records(records, bootstrap_seed=bootstrap_seed)
    (out / "scientific_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    (out / "evidence_audit.json").write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n")

    # Stable CSV for downstream plotting/table generation.
    with (out / "model_summary.csv").open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["model_id", "n_records", "n_tasks", "task_success", "ci95_low", "ci95_high", "replay_admissible_fraction", "human_audited_fraction"])
        for model, data in summary["models"].items():
            ts = data["metrics"]["task_success"]
            w.writerow([model, data["n_records"], data["n_tasks"], ts["mean"], ts["ci95"][0], ts["ci95"][1], data["replay_admissible_fraction"], data["human_audited_fraction"]])

    md = ["# Scientific result summary", "", "Generated only after the external-evidence gate passed.", "", "| Model | Tasks | Success (task-cluster mean) | 95% CI | Replay-admissible | Human-audited |", "|---|---:|---:|---:|---:|---:|"]
    tex_rows = []
    for model, data in summary["models"].items():
        ts = data["metrics"]["task_success"]
        md.append(f"| {model} | {data['n_tasks']} | {_fmt(ts['mean'])} | [{_fmt(ts['ci95'][0])}, {_fmt(ts['ci95'][1])}] | {_fmt(data['replay_admissible_fraction'])} | {_fmt(data['human_audited_fraction'])} |")
        safe_model = model.replace("_", r"\_")
        tex_rows.append(f"{safe_model} & {data['n_tasks']} & {_fmt(ts['mean'])} & [{_fmt(ts['ci95'][0])}, {_fmt(ts['ci95'][1])}] & {_fmt(data['replay_admissible_fraction'])} & {_fmt(data['human_audited_fraction'])} \\\\")
    (out / "model_summary.md").write_text("\n".join(md) + "\n")
    tex = "\\begin{tabular}{lrrrrr}\n\\toprule\nModel & Tasks & Success & 95\\% CI & Replay adm. & Human audit \\\\\n\\midrule\n" + "\n".join(tex_rows) + "\n\\bottomrule\n\\end{tabular}\n"
    (out / "model_summary.tex").write_text(tex)
    return {"audit": audit, "summary": summary, "output_dir": str(out)}
