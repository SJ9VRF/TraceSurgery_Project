from __future__ import annotations
from typing import Callable, Any
from tracesurgery.core.models import Action, Observation, Task
from .base import Agent
from .scripted import ScriptedAgent

class RepeatingFailureAgent(Agent):
    """Diagnostic baseline that makes a rejected action repeatedly.

    Useful only for validating failure/recovery instrumentation; never use it as
    a scientific baseline in a paper comparison.
    """
    name = "repeating-failure"
    model = "diagnostic-local"
    def act(self, observation: Observation, step: int) -> Action:
        return Action(tool="unknown_tool", args={})

class UnsafeDiagnosticAgent(Agent):
    name = "unsafe-diagnostic"
    model = "diagnostic-local"
    def act(self, observation: Observation, step: int) -> Action:
        return Action(tool="delete", args={"path":"production.data"})

class ReplayAgent(Agent):
    """Replays a supplied action trace exactly for deterministic regression tests."""
    name = "replay"
    model = "trace"
    def __init__(self, actions: list[dict[str, Any]]):
        self._raw = actions
    def reset(self, task: Task, seed: int = 0):
        super().reset(task, seed)
        self._actions = [Action.model_validate(a) for a in self._raw]
    def act(self, observation: Observation, step: int) -> Action:
        return self._actions[step] if step < len(self._actions) else Action(tool="finish")

class CallablePolicyAgent(Agent):
    """Provider-neutral adapter around any function returning an Action-like dict.

    This is the seam for Claude/GPT/local VLM integrations. The benchmark does
    not own provider credentials or silently make network calls.
    """
    def __init__(self, policy: Callable[[Task, Observation, int], dict[str, Any] | Action], *, name="callable", model="external"):
        self.policy = policy
        self.name = name
        self.model = model
    def act(self, observation: Observation, step: int) -> Action:
        out = self.policy(self.task, observation, step)
        return out if isinstance(out, Action) else Action.model_validate(out)
