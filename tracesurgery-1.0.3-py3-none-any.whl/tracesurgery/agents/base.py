from __future__ import annotations
from abc import ABC, abstractmethod
from tracesurgery.core.models import Action, Observation, Task

class Agent(ABC):
    name = "agent"
    model = "unknown"
    def reset(self, task: Task, seed: int = 0):
        self.task = task
        self.seed = seed
    @abstractmethod
    def act(self, observation: Observation, step: int) -> Action: ...
