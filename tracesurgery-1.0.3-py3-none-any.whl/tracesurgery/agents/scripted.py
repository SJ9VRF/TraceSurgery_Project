from __future__ import annotations
from tracesurgery.core.models import Action, Observation, Task
from .base import Agent

class ScriptedAgent(Agent):
    name = "scripted"
    model = "deterministic-local"
    def reset(self, task: Task, seed: int = 0):
        super().reset(task, seed)
        script = task.metadata.get("script", [])
        self.actions = [Action.model_validate(x) for x in script]
    def act(self, observation: Observation, step: int) -> Action:
        if step < len(self.actions):
            return self.actions[step]
        return Action(tool="finish")

class FaultyScriptedAgent(ScriptedAgent):
    name = "faulty-scripted"
    def reset(self, task: Task, seed: int = 0):
        super().reset(task, seed)
        fault = task.metadata.get("fault_injection")
        if fault and 0 <= fault.get("step", -1) < len(self.actions):
            self.actions[fault["step"]] = Action.model_validate(fault["action"])
