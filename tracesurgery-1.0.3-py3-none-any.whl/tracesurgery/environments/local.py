from __future__ import annotations
import random
from tracesurgery.core.models import Action, Observation, Task
from tracesurgery.core.utils import deep_copy, get_path, set_path, delete_path, project_state
from .base import Environment

class LocalSandbox(Environment):
    """Deterministic state machine for development, CI, and benchmark validation.

    Ground-truth state and agent observations are deliberately separated.
    Private state can live under `_hidden` or be excluded using
    task.metadata.visible_paths. This local adapter is not claimed to replace a
    browser/desktop benchmark; it validates the TraceSurgery contracts without
    external credentials.
    """
    def __init__(self):
        self.state = {}
        self.terminal = False
        self.rng = random.Random(0)
        self.task: Task | None = None

    def reset(self, task: Task, seed: int = 0) -> Observation:
        self.task = task
        self.rng = random.Random(seed)
        self.state = deep_copy(task.initial_state)
        self.state.setdefault("events", [])
        self.terminal = False
        return self._obs("reset")

    def _obs(self, msg=""):
        visible_paths = None if self.task is None else self.task.metadata.get("visible_paths")
        uncertainty = [] if self.task is None else list(self.task.metadata.get("observation_uncertainty", []))
        return Observation(visible_state=project_state(self.state, visible_paths), message=msg, uncertainty=uncertainty)

    def snapshot(self):
        return deep_copy(self.state)

    def is_terminal(self):
        return self.terminal

    def step(self, action: Action) -> Observation:
        t, a = action.tool, action.args
        valid = True
        if t == "set":
            set_path(self.state, a["path"], a.get("value"))
        elif t == "append":
            arr = get_path(self.state, a["path"])
            if arr is None:
                set_path(self.state, a["path"], [])
                arr = get_path(self.state, a["path"])
            if not isinstance(arr, list):
                valid = False
            else:
                arr.append(deep_copy(a.get("value")))
        elif t == "delete":
            delete_path(self.state, a["path"])
        elif t == "copy":
            set_path(self.state, a["dst"], deep_copy(get_path(self.state, a["src"])))
        elif t == "assert":
            pass
        elif t == "finish":
            self.terminal = True
        else:
            valid = False
            self.state["events"].append({"type": "invalid_tool", "tool": t})
        self.state["events"].append({"type": "action", "tool": t, "args": deep_copy(a), "valid": valid})
        return self._obs(t)

    def restore(self, snapshot: dict) -> Observation:
        """Restore a previously captured ground-truth checkpoint.

        This method is intentionally an evaluator capability, not an agent tool.
        Production adapters should implement equivalent checkpoint/restore or
        deterministic replay semantics without exposing privileged state.
        """
        self.state = deep_copy(snapshot)
        self.terminal = False
        return self._obs("restore")
