from __future__ import annotations
import math, random
from collections import defaultdict
from typing import Iterable

def wilson_interval(successes:int,n:int,z:float=1.959963984540054)->tuple[float,float]:
    if n<=0:return (float('nan'),float('nan'))
    p=successes/n; den=1+z*z/n; center=(p+z*z/(2*n))/den
    half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return max(0,center-half),min(1,center+half)

def success_at_k(by_task:dict[str,list[bool]],k:int)->float:
    vals=[]
    for xs in by_task.values():
        if len(xs)>=k: vals.append(any(xs[:k]))
    return sum(vals)/len(vals) if vals else float('nan')

def task_cluster_bootstrap(rows:list[dict], metric:str, n_boot:int=2000, seed:int=0)->dict:
    """Cluster bootstrap over tasks, preserving repeated trials within task."""
    groups=defaultdict(list)
    for r in rows:
        v=r.get(metric)
        if v is not None: groups[r['task_id']].append(float(v))
    ids=list(groups)
    if not ids:return {'mean':None,'ci95':[None,None],'n_tasks':0}
    task_means={k:sum(v)/len(v) for k,v in groups.items()}; point=sum(task_means.values())/len(task_means)
    rng=random.Random(seed); boots=[]
    for _ in range(n_boot):
        sample=[rng.choice(ids) for _ in ids]; boots.append(sum(task_means[x] for x in sample)/len(sample))
    boots.sort(); lo=boots[int(.025*(n_boot-1))]; hi=boots[int(.975*(n_boot-1))]
    return {'mean':point,'ci95':[lo,hi],'n_tasks':len(ids),'bootstrap_unit':'task'}

def paired_task_bootstrap(a:list[dict],b:list[dict],metric:str,n_boot:int=5000,seed:int=0)->dict:
    """Paired task-level delta B-A; only common task IDs are compared."""
    def agg(rows):
        g=defaultdict(list)
        for r in rows:
            if r.get(metric) is not None:g[r['task_id']].append(float(r[metric]))
        return {k:sum(v)/len(v) for k,v in g.items()}
    A,B=agg(a),agg(b); ids=sorted(set(A)&set(B))
    if not ids:return {'delta':None,'ci95':[None,None],'n_tasks':0}
    ds={k:B[k]-A[k] for k in ids}; point=sum(ds.values())/len(ds); rng=random.Random(seed); boots=[]
    for _ in range(n_boot):
        s=[rng.choice(ids) for _ in ids]; boots.append(sum(ds[x] for x in s)/len(s))
    boots.sort(); return {'delta':point,'ci95':[boots[int(.025*(n_boot-1))],boots[int(.975*(n_boot-1))]],'n_tasks':len(ids)}
