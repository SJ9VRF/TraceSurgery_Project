from __future__ import annotations
import json
from pathlib import Path
from collections import defaultdict
from tracesurgery.io import read_results
from tracesurgery.metrics.core import trial_metrics
from tracesurgery.statistics import task_cluster_bootstrap, success_at_k, wilson_interval

def summarize(results_path,output_path,bootstrap_seed=0):
    trials=read_results(results_path); metrics=[trial_metrics(t) for t in trials]
    rows=[{'task_id':t.task_id,'agent':t.agent,**m} for t,m in zip(trials,metrics)]
    names=['task_success','first_failure_position','failure_count','recovery_rate','mean_recovery_steps',
        'mean_failure_detection_latency','max_error_propagation_depth','max_failure_cascade_size','high_risk_action_count',
        'blocked_high_risk_action_count','cost_usd','latency_ms']
    summary={'n_trials':len(rows),'n_tasks':len({r['task_id'] for r in rows}),'ci_unit':'task','metrics':{}}
    for k in names: summary['metrics'][k]=task_cluster_bootstrap(rows,k,seed=bootstrap_seed)
    by_agent={}
    for agent in sorted({r['agent'] for r in rows}):
        rs=[r for r in rows if r['agent']==agent]; by_task=defaultdict(list)
        for r in rs:by_task[r['task_id']].append(bool(r['task_success']))
        successes=sum(bool(r['task_success']) for r in rs); lo,hi=wilson_interval(successes,len(rs)) if rs else (None,None)
        maxk=max((len(v) for v in by_task.values()),default=0)
        by_agent[agent]={'task_clustered_success':task_cluster_bootstrap(rs,'task_success',seed=bootstrap_seed),
            'trial_success_wilson':{'rate':successes/len(rs) if rs else None,'ci95':[lo,hi],'n_trials':len(rs)},
            'success_at_k':{str(k):success_at_k(by_task,k) for k in range(1,maxk+1)}}
    summary['by_agent']=by_agent
    Path(output_path).parent.mkdir(parents=True,exist_ok=True); Path(output_path).write_text(json.dumps(summary,indent=2)); return summary
