from __future__ import annotations
import time, uuid
from tracesurgery.core.models import Task, StepRecord, TrialResult, InterventionEvent
from tracesurgery.core.utils import state_diff, get_path
from tracesurgery.graders.composite import CompositeGrader
from tracesurgery.failures.detector import infer_failures
from tracesurgery.failures.causal_graph import CausalFailureGraph
from tracesurgery.safety import classify_action, should_block

class TrialRunner:
    """Reference runner. It preserves the exact pre-action observation, keeps
    interventions separate from agent failures, and never exposes ground truth
    to the policy. Safety blocking is opt-in through task metadata.safety_mode.
    """
    def __init__(self, environment, grader=None):
        self.environment=environment; self.grader=grader or CompositeGrader()

    def run(self, task:Task, agent, seed:int=0, perturbations=None)->TrialResult:
        perturbations=perturbations or []; obs=self.environment.reset(task,seed); agent.reset(task,seed)
        trajectory=[]; total_latency=0; total_cost=0.0; interventions=[]
        for step in range(task.max_steps):
            step_interventions=[]
            for p in perturbations:
                if p.maybe_apply(self.environment.state,step):
                    ev=InterventionEvent(id=f'I{len(interventions)+1}',step=step,name=p.name,metadata={'seed':seed})
                    interventions.append(ev); step_interventions.append(ev)
            # Intervention can change what is observable before the decision.
            if step_interventions and hasattr(self.environment,'_obs'): obs=self.environment._obs('intervention')
            pre_obs=obs; before=self.environment.snapshot(); t0=time.perf_counter(); action=agent.act(pre_obs,step)
            risk=classify_action(action)
            enforce=task.metadata.get('safety_mode','audit')=='enforce'
            blocked=bool(enforce and should_block(action,task))
            if blocked:
                post_obs=self.environment._obs('blocked_high_risk_action') if hasattr(self.environment,'_obs') else pre_obs
            else:
                post_obs=self.environment.step(action)
            latency=int((time.perf_counter()-t0)*1000); total_latency+=latency; after=self.environment.snapshot()
            mismatches=[]
            for path,believed in action.belief_state.items():
                actual=get_path(before,path)
                if actual!=believed: mismatches.append({'path':path,'believed':believed,'actual':actual})
            trajectory.append(StepRecord(step=step,observation=pre_obs,action=action,post_observation=post_obs,
                environment_state_before=before,expected_state_after=action.expected_state_after,environment_state_after=after,
                state_delta=state_diff(before,after),belief_mismatches=mismatches,interventions=step_interventions,
                perturbations_applied=[x.name for x in step_interventions],risk=risk,blocked=blocked,latency_ms=latency,cost_usd=0.0))
            obs=post_obs
            if blocked or self.environment.is_terminal(): break
        final=self.environment.snapshot(); grades=self.grader.grade(task,final)
        failures,edges,ponr=infer_failures(trajectory,task_success=grades['success'])
        graph=CausalFailureGraph(failures,edges)
        return TrialResult(task_id=task.id,trial_id=str(uuid.uuid4()),agent=agent.name,model=agent.model,seed=seed,
            trajectory=trajectory,final_state=final,grader_results=grades,failure_events=failures,interventions=interventions,
            causal_edges=edges,root_failures=graph.root_failures() if failures else [],point_of_no_return=ponr,
            success=grades['success'],latency_ms=total_latency,cost_usd=total_cost,
            metadata={'perturbations':[p.name for p in perturbations],'safety_mode':task.metadata.get('safety_mode','audit')})
