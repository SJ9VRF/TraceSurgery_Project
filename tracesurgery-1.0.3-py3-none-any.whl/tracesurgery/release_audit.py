from __future__ import annotations

import json
import re
import tomllib
from dataclasses import dataclass, asdict
from pathlib import Path

from tracesurgery import __version__

FORBIDDEN_PRE_EMPIRICAL = [
    r"\bSOTA\b",
    r"\bstate[- ]of[- ]the[- ]art\b",
    r"\boutperforms?\b",
    r"\bimproves?\s+\d+(?:\.\d+)?%",
    r"\bproves? root cause\b",
    r"\b500 real[- ]world tasks\b",
]

PUBLIC_FILES = [
    "README.md",
    "PROJECT_STATUS.md",
    "website/index.html",
    "DATASET_CARD.md",
]

REQUIRED_ARTIFACTS = [
    "README.md",
    "PROJECT_STATUS.md",
    "DATASET_CARD.md",
    "CITATION.cff",
    "LICENSE",
    "SECURITY.md",
    "CONTRIBUTING.md",
    "docs/PUBLIC_CLAIMS.md",
    "docs/NOVELTY_AUDIT_2026-09.md",
    "docs/COUNTERFACTUAL_PROTOCOL.md",
    "docs/REPRODUCIBILITY.md",
    "docs/PREREGISTRATION.md",
    "docs/HIRING_MANAGER_BRIEF.md",
    "docs/REVIEWER_GUIDE.md",
    "docs/BASELINE_CONTRACT.md",
    "docs/EXTERNAL_STUDY_PLAN.md",
    "docs/EXTERNAL_EXECUTION_HANDOFF.md",
    "docs/SCIENTIFIC_RESULT_PIPELINE.md",
    "docs/ADAPTER_CONFORMANCE.md",
    "docs/SCHEMA_COMPATIBILITY.md",
    "docs/V1_RELEASE_NOTES.md",
    "configs/external_study.example.yaml",
    "docs/templates/EVIDENCE_RECORD.json",
    "tests/test_study.py",
    "tests/test_evidence.py",
    "tests/test_scientific_report.py",
    "paper/main.tex",
    "website/index.html",
    "tests/test_counterfactual.py",
    "tests/test_quality_gates.py",
    "tests/test_cli_public_surface.py",
    "scripts/verify_release.py",
    "scripts/demo_5min.py",
    "docs/5_MINUTE_DEMO.md",
    ".github/pull_request_template.md",
    ".github/ISSUE_TEMPLATE/bug_report.yml",
    ".github/ISSUE_TEMPLATE/validity_issue.yml",
    "docs/evidence/EVIDENCE_LAYER.md",
    "docs/evidence/FAILED_EXPERIMENTS.md",
    "docs/evidence/DECISION_LOG.md",
    "docs/evidence/EVAL_TABLES.md",
    "docs/evidence/UNEXPECTED_FINDINGS.md",
    "artifacts/README.md",
    "artifacts/experiment_logs/EXPERIMENT_JOURNAL.md",
    "artifacts/experiment_logs/experiment_journal.jsonl",
    "artifacts/eval_runs/local_demo_eval.csv",
    "artifacts/failure_examples/CASE-001_wrong_summary.json",
    "artifacts/qualitative_cases/CASE-001.md",
    "artifacts/git_history/HISTORY_POLICY.md",
    "docs/evidence/CLAIM_LEDGER.md",
    "artifacts/claim_ledger.json",
    "scripts/verify_evidence_layer.py",
    "tests/test_claim_ledger.py",
]

@dataclass
class Finding:
    severity: str
    check: str
    message: str
    path: str | None = None


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def _local_markdown_links(text: str) -> list[str]:
    links = []
    for match in re.finditer(r"\[[^\]]+\]\(([^)]+)\)", text):
        target = match.group(1).strip().split()[0].strip("<>\"")
        if not target or target.startswith(("http://", "https://", "mailto:", "#")):
            continue
        target = target.split("#", 1)[0].split("?", 1)[0]
        if target:
            links.append(target)
    return links


def audit(root: str | Path) -> dict:
    root = Path(root)
    findings: list[Finding] = []

    def add(severity: str, check: str, message: str, path: str | None = None) -> None:
        findings.append(Finding(severity, check, message, path))

    # Required artifacts.
    for rel in REQUIRED_ARTIFACTS:
        if not (root / rel).exists():
            add("error", "required_artifact", f"missing required artifact: {rel}", rel)

    # Version consistency.
    pyproject = root / "pyproject.toml"
    if pyproject.exists():
        data = tomllib.loads(_read(pyproject))
        pv = str(data.get("project", {}).get("version", ""))
        if pv != __version__:
            add("error", "version_consistency", f"pyproject version {pv!r} != package version {__version__!r}", "pyproject.toml")
        authors = [x.get("name") for x in data.get("project", {}).get("authors", [])]
        if "Aura Yavary" not in authors:
            add("error", "author_identity", "pyproject author must include Aura Yavary", "pyproject.toml")

    citation = root / "CITATION.cff"
    if citation.exists():
        ct = _read(citation)
        citation_has_author = ("Aura Yavary" in ct) or ("given-names: Aura" in ct and "family-names: Yavary" in ct)
        if not citation_has_author:
            add("error", "author_identity", "CITATION.cff must identify Aura Yavary", "CITATION.cff")
        m = re.search(r"^version:\s*[\"']?([^\"'\s]+)", ct, flags=re.M)
        if m and m.group(1) != __version__:
            add("error", "version_consistency", f"CITATION version {m.group(1)!r} != package version {__version__!r}", "CITATION.cff")

    for rel in ["PROJECT_STATUS.md", "paper/main.tex", "website/index.html"]:
        p = root / rel
        if p.exists() and __version__ not in _read(p):
            add("error", "version_consistency", f"public artifact does not contain release version {__version__}", rel)

    # Local documentation links must resolve inside the release tree.
    doc_files = [root / "README.md", *sorted((root / "docs").rglob("*.md")), *sorted((root / "artifacts").rglob("*.md"))] if (root / "docs").exists() else [root / "README.md"]
    for doc in doc_files:
        if not doc.exists():
            continue
        for target in _local_markdown_links(_read(doc)):
            resolved = (doc.parent / target).resolve()
            try:
                resolved.relative_to(root.resolve())
            except ValueError:
                add("error", "documentation_link", f"relative link escapes release root: {target}", str(doc.relative_to(root)))
                continue
            if not resolved.exists():
                add("error", "documentation_link", f"broken relative link: {target}", str(doc.relative_to(root)))

    # Public claim discipline.
    for rel in PUBLIC_FILES:
        p = root / rel
        if not p.exists():
            continue
        text = _read(p)
        for pattern in FORBIDDEN_PRE_EMPIRICAL:
            # Allow explicit negations/policies by excluding lines containing warning language.
            for i, line in enumerate(text.splitlines(), start=1):
                if re.search(pattern, line, flags=re.I):
                    lower = re.sub(r"[*_`]+", "", line.lower())
                    if any(token in lower for token in ["do not", "does not", "not claim", "not claimed", "forbidden", "without", "until", "no sota", "hypothesis", "pending"]):
                        continue
                    add("error", "public_claims", f"unsupported pre-empirical wording: {line.strip()[:160]}", f"{rel}:{i}")

    # No cache/generated-build junk in release tree.
    junk = []
    forbidden_dirs = {"__pycache__", ".pytest_cache", ".ruff_cache", "build", "dist"}
    for p in root.rglob("*"):
        rel = p.relative_to(root)
        if any(part in forbidden_dirs or part.endswith(".egg-info") for part in rel.parts):
            junk.append(str(rel))
            continue
        if p.is_file() and p.suffix in {".pyc", ".pyo"}:
            junk.append(str(rel))
    if junk:
        add("warning", "release_hygiene", f"cache/generated build artifacts present ({len(junk)} paths); exclude them from release archive")

    # Paper must not contain fabricated numeric result language.
    paper = root / "paper/main.tex"
    if paper.exists():
        text = _read(paper)
        suspicious = re.findall(r"(?:improv(?:e|ed)|outperform(?:s|ed)?|increase(?:d)?|reduce(?:d)?)\s+(?:by\s+)?\d+(?:\.\d+)?\\?%", text, flags=re.I)
        if suspicious:
            add("error", "paper_claims", f"paper contains result-like numeric claims before external study: {suspicious[:3]}", "paper/main.tex")

    errors = [asdict(x) for x in findings if x.severity == "error"]
    warnings = [asdict(x) for x in findings if x.severity == "warning"]
    return {
        "project": "TraceSurgery",
        "version": __version__,
        "author": "Aura Yavary",
        "ok": not errors,
        "n_errors": len(errors),
        "n_warnings": len(warnings),
        "errors": errors,
        "warnings": warnings,
    }


def write_report(root: str | Path, output: str | Path) -> dict:
    report = audit(root)
    p = Path(output)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return report
