from __future__ import annotations
import re
from tracesurgery.core.models import AssertionSpec
from tracesurgery.core.utils import get_path

def evaluate_assertion(state: dict, spec: AssertionSpec) -> tuple[bool, dict]:
    actual = get_path(state, spec.path)
    expected = spec.equals if spec.type in {"equals", "approx"} else spec.contains
    if spec.type == "equals":
        ok = actual == spec.equals
    elif spec.type == "contains":
        ok = spec.contains in actual if actual is not None else False
    elif spec.type == "exists":
        ok = actual is not None
    elif spec.type == "not_exists":
        ok = actual is None
    elif spec.type == "not_contains":
        ok = spec.contains not in actual if actual is not None else True
    elif spec.type == "approx":
        tol = float(spec.value if spec.value is not None else 1e-6)
        try: ok = abs(float(actual) - float(spec.equals)) <= tol
        except (TypeError, ValueError): ok = False
    elif spec.type == "regex":
        ok = isinstance(actual, str) and bool(re.search(str(spec.contains), actual))
    elif spec.type == "length":
        try: ok = len(actual) == int(spec.value)
        except (TypeError, ValueError): ok = False
    elif spec.type == "subset":
        try:
            target = spec.value if spec.value is not None else spec.contains
            ok = set(target).issubset(set(actual))
        except TypeError:
            ok = False
    else:
        ok = False
    return ok, {"type": spec.type, "path": spec.path, "actual": actual, "expected": expected, "value": spec.value}
