from __future__ import annotations
from tracesurgery.perturbations.base import Perturbation

def _p(name, step, fn, severity="medium"):
    return Perturbation(name=name, trigger_step=step, apply_fn=fn, severity=severity)

def close_last_tab(step=1): return _p("close_last_tab",step,lambda s:s.setdefault("browser",{}).setdefault("tabs",[]).pop() if s.setdefault("browser",{}).setdefault("tabs",[]) else None)
def reorder_tabs(step=1): return _p("reorder_tabs",step,lambda s:s.setdefault("browser",{}).__setitem__("tabs",list(reversed(s.setdefault("browser",{}).get("tabs",[])))))
def session_expired(step=1): return _p("session_expired",step,lambda s:s.setdefault("browser",{}).__setitem__("session","expired"),"high")
def popup_overlay(step=1): return _p("popup_overlay",step,lambda s:s.setdefault("browser",{}).__setitem__("modal",{"visible":True,"kind":"notice"}))
def page_error(step=1): return _p("page_error",step,lambda s:s.setdefault("browser",{}).__setitem__("status","temporary_error"))
def stale_tab(step=1): return _p("stale_tab",step,lambda s:s.setdefault("browser",{}).__setitem__("stale",True))
def lost_focus(step=1): return _p("lost_focus",step,lambda s:s.__setitem__("active_app","desktop"))
def renamed_control(step=1): return _p("renamed_control",step,lambda s:s.setdefault("ui",{}).__setitem__("primary_label","Continue"))
def hidden_field(step=1): return _p("hidden_field",step,lambda s:s.setdefault("ui",{}).__setitem__("field_visible",False))
def reordered_list(step=1): return _p("reordered_list",step,lambda s:s.setdefault("ui",{}).__setitem__("items",list(reversed(s.setdefault("ui",{}).get("items",[])))))
def missing_value(step=1): return _p("missing_value",step,lambda s:s.setdefault("data",{}).__setitem__("value",None))
def duplicate_value(step=1): return _p("duplicate_value",step,lambda s:s.setdefault("data",{}).__setitem__("duplicate",True))
def malformed_entry(step=1): return _p("malformed_entry",step,lambda s:s.setdefault("data",{}).__setitem__("value","<malformed>"))
def outdated_information(step=1): return _p("outdated_information",step,lambda s:s.setdefault("data",{}).__setitem__("fresh",False))
def unsaved_document(step=1): return _p("unsaved_document",step,lambda s:s.setdefault("document",{}).__setitem__("saved",False))
def changed_selection(step=1): return _p("changed_selection",step,lambda s:s.setdefault("spreadsheet",{}).__setitem__("selected_cell","A1"))
def moved_file(step=1): return _p("moved_file",step,lambda s:s.setdefault("filesystem",{}).__setitem__("target_path","/tmp/moved"))
def interrupted_workflow(step=1): return _p("interrupted_workflow",step,lambda s:s.__setitem__("active_app","notification_center"))
def app_restart(step=1): return _p("app_restart",step,lambda s:s.setdefault("app",{}).__setitem__("restarted",True))
def corrupted_intermediate(step=1): return _p("corrupted_intermediate",step,lambda s:s.setdefault("workspace",{}).__setitem__("intermediate","CORRUPTED"),"high")

REGISTRY={f.__name__:f for f in [close_last_tab,reorder_tabs,session_expired,popup_overlay,page_error,stale_tab,lost_focus,renamed_control,hidden_field,reordered_list,missing_value,duplicate_value,malformed_entry,outdated_information,unsaved_document,changed_selection,moved_file,interrupted_workflow,app_restart,corrupted_intermediate]}
