from __future__ import annotations
from dataclasses import dataclass
from typing import Callable

@dataclass
class Perturbation:
    name: str
    trigger_step: int
    apply_fn: Callable[[dict], None]
    severity: str = "medium"
    seed: int = 0

    def maybe_apply(self, state: dict, step: int) -> bool:
        if step == self.trigger_step:
            self.apply_fn(state)
            state.setdefault("events", []).append({"type":"perturbation", "name":self.name})
            return True
        return False

def close_tab(step=1):
    def f(s):
        tabs=s.setdefault("browser",{}).setdefault("tabs",[])
        if tabs: tabs.pop()
    return Perturbation("close_tab", step, f)

def stale_selection(step=1):
    def f(s): s.setdefault("spreadsheet",{})["selected_cell"]="A1"
    return Perturbation("stale_selection", step, f)

def unsaved_document(step=1):
    def f(s): s.setdefault("document",{})["saved"]=False
    return Perturbation("unsaved_document", step, f)

def missing_resource(step=1):
    def f(s): s.setdefault("resources",{}).pop("target", None)
    return Perturbation("missing_resource", step, f)
