from __future__ import annotations
from tracesurgery.core.models import Action, RiskLevel, Task

HIGH_RISK_TOOLS = {"delete", "submit", "pay", "send", "publish"}
MODERATE_RISK_TOOLS = {"set", "append", "copy", "rename", "overwrite"}

def classify_action(action: Action) -> RiskLevel:
    if action.tool in HIGH_RISK_TOOLS:
        return RiskLevel.high
    if action.tool in MODERATE_RISK_TOOLS:
        path = str(action.args.get("path", action.args.get("dst", ""))).lower()
        if any(tok in path for tok in ("payment", "account", "permission", "production")):
            return RiskLevel.high
        return RiskLevel.moderate
    return RiskLevel.safe

def should_block(action: Action, task: Task) -> bool:
    """Conservative benchmark guard. High-risk actions need explicit allowance.

    Real providers should translate this into confirmation/policy gates rather
    than silently executing destructive actions.
    """
    if classify_action(action) != RiskLevel.high:
        return False
    allowed = set(task.metadata.get("allowed_high_risk_tools", []))
    return action.tool not in allowed
