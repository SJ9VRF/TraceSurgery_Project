from __future__ import annotations
from tracesurgery.core.models import Task
from tracesurgery.core.utils import get_path

RESERVED_PRIVATE_PREFIX='_hidden'

def lint_task(t:Task)->list[dict]:
    issues=[]
    def add(level,code,msg):issues.append({'level':level,'code':code,'message':msg})
    if not t.instruction.strip():add('error','empty_instruction','instruction is blank')
    if t.max_steps<max(2,t.horizon*2):add('warning','tight_budget','max_steps may be inconsistent with horizon')
    sigs=[(x.type,x.path,repr(x.equals),repr(x.contains),repr(x.value)) for x in t.success_assertions]
    if len(sigs)!=len(set(sigs)):add('warning','duplicate_success_assertion','exact duplicate success assertion')
    for spec in t.success_assertions+t.safety_constraints:
        if not spec.path:add('error','missing_path','assertion has no path')
        if spec.path and spec.path.startswith(RESERVED_PRIVATE_PREFIX) and t.metadata.get('visible_paths'):
            # private grading is valid; exposing it is not
            if any(str(v).startswith(RESERVED_PRIVATE_PREFIX) for v in t.metadata.get('visible_paths',[])):
                add('error','hidden_state_leak','visible_paths exposes _hidden state')
    if not t.safety_constraints and t.risk_level.value!='safe':add('warning','missing_safety_assertion','non-safe task has no safety constraint')
    if 'scripted_actions' in t.metadata and not isinstance(t.metadata['scripted_actions'],list):add('error','bad_oracle','scripted_actions must be a list')
    return issues

def lint_suite(tasks:list[Task])->dict:
    ids=[t.id for t in tasks]; details={t.id:lint_task(t) for t in tasks}; duplicates=sorted({x for x in ids if ids.count(x)>1})
    if duplicates: details['__suite__']=[{'level':'error','code':'duplicate_ids','message':str(duplicates)}]
    errors=sum(i['level']=='error' for xs in details.values() for i in xs); warnings=sum(i['level']=='warning' for xs in details.values() for i in xs)
    return {'valid':errors==0,'n_tasks':len(tasks),'errors':errors,'warnings':warnings,'issues':details}
