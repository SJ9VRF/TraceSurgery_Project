# Changelog

## 1.0.3 - 2026-09-27

Claim-traceability patch. Added a machine-readable Claim Ledger mapping every released local-evidence claim to raw artifacts and an executable verification rule. Added `scripts/verify_evidence_layer.py`, release-gated claim-ledger artifacts, and regression tests that recompute public counts and mechanistic statements from the raw deterministic demo. No external performance claim was added.

## 1.0.2 - 2026-09-26

Evidence-layer patch. Added an inspectable experiment journal, negative-result log, decision log, real local eval tables, unexpected findings, raw intervention artifacts, qualitative failure cases, and explicit Git-history provenance. Release audit now requires and recursively validates Evidence Layer documentation/artifacts, and regression tests assert that published local tables match raw demo branches. No frontier-model performance claim was added.

## 1.0.1 - 2026-09-26

Public-release hardening patch. Removed generated `build/` source duplicates from the release tree; added a five-minute deterministic demo; added GitHub bug/validity issue templates and a validity-focused pull-request template; expanded release-audit requirements to cover those public entry points; and tightened release hygiene against generated build/dist/egg-info artifacts. No scientific performance claim changed.

## 1.0.0 - 2026-09-26

First stable research-artifact release.

- Raised regression suite to 41 tests and release-gated package coverage at 90% (92.87% in this release).
- Added direct public-CLI regression coverage rather than excluding CLI code from quality metrics.
- Added versioned `StudySpec` and `RunEntry` research records plus an explicit schema compatibility policy.
- Added top-level `--version`, v1 release notes, and a 60-second technical review path.
- Strengthened `release-audit` with cross-artifact version consistency and broken local documentation-link checks.
- Added one-command `scripts/verify_release.py` covering compile, tests/coverage, doctor, release audit, 500-task lint/oracle validation, and wheel build.
- Added wheel-build verification to CI and `make verify`.
- No frontier-model performance result is introduced; scientific claims remain gated on external execution.

## 0.9.0 - 2026-09-26

- Added concurrency-safe atomic study-ledger claims with worker attribution and explicit complete/failed transitions.
- Strengthened evidence provenance with on-disk manifest existence and SHA-256 verification.
- Required model revision, benchmark version, grader revision, and external provenance for claim-eligible records.
- Added fail-closed scientific aggregation that emits JSON/CSV/Markdown/LaTeX summaries only after evidence audit passes.
- Added `study-claim`, `study-mark`, and `evidence-report` CLI flows.
- Added scientific result-pipeline and adapter-conformance documentation plus regression tests.

## 0.8.0 - 2026-09-26

- Added deterministic external-study specifications and a resumable run ledger.
- Added provider/environment adapter conformance contracts without bundling unexecuted proprietary integrations.
- Added a scientific-evidence schema and hard audit gate that rejects local validation/synthetic demos from performance claims.
- Added an external execution handoff, frozen evidence-record template, and CLI commands: `study-init`, `study-status`, and `evidence-audit`.
- Expanded release audit to require the external-study/evidence artifacts.

## 0.7.0 - 2026-09-25

- Added executable `release-audit` for author/version/artifact/claim consistency.
- Added experiment manifests with deterministic suite hashing and runtime provenance.
- Added `tracesurgery doctor` preflight.
- Added public-claims policy, researcher quickstart, security policy, and validity-focused contribution rules.
- Added hiring-manager and reviewer briefs, baseline contract, external frontier-study plan, and artifact index.
- Added clean-release packaging policy excluding caches and bytecode.

## 0.5.0 - 2026-09-25

Causal-rigor release.

- Added no-intervention replay-fidelity gating at every tested checkpoint.
- Added stable hashes for source checkpoints, action continuations, and branch final states.
- Added executable `DiagnosisClaim` and diagnosis-faithfulness evaluation.
- Added bounded minimum-cardinality oracle action-repair-set search as an upper-bound probe.
- Recovery AUC / last-recoverable checkpoint use causally admissible branches only.
- Added CI across Python 3.10-3.12, reproducibility contract, preregistration template, experiment card, and hiring-signal audit.
- Tightened public claim language around minimal repair-family discovery and GUI recovery.

## 0.4.0 - 2026-09-25

- Renamed the research direction from RecoveryBench to TraceSurgery after novelty audit.
- Added action/state/suffix counterfactual branch-and-replay engine.
- Added recovery-surface summaries and causal-diagnosis framing.
