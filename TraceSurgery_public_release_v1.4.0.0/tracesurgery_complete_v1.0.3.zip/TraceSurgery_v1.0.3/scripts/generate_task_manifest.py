from pathlib import Path
import yaml, json
rows=[]
for p in Path("tasks/samples").glob("*.yaml"):
    d=yaml.safe_load(p.read_text()); rows.append({k:d.get(k) for k in ["id","applications","horizon","statefulness","recovery_complexity","risk_level"]})
print(json.dumps(rows, indent=2))
