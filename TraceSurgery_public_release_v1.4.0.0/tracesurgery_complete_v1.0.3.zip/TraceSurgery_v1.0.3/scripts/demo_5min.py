#!/usr/bin/env python3
"""Run the deterministic TraceSurgery counterfactual semantics demo.

This is a software-validation entry point, not a scientific benchmark run.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="runs/demo_5min.json")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = (root / args.output).resolve() if not Path(args.output).is_absolute() else Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable,
        "-m",
        "tracesurgery.cli",
        "surgery",
        "--task",
        str(root / "tasks/samples/spreadsheet_formula.yaml"),
        "--output",
        str(output),
    ]
    proc = subprocess.run(cmd, cwd=root, text=True, capture_output=True)
    if proc.returncode != 0:
        sys.stderr.write(proc.stdout)
        sys.stderr.write(proc.stderr)
        return proc.returncode
    data = json.loads(output.read_text())
    branches = data.get("branches") or data.get("records") or []
    if not branches:
        raise SystemExit("demo produced no branch records")
    replay_faithful = [b for b in branches if b.get("kind") == "no_intervention" and b.get("replay_matches_source") is True]
    effective = [b for b in branches if b.get("outcome_gain") in (1, 1.0, True)]
    # Fall back to explicit success delta fields used by older serialized demo records.
    if not effective:
        effective = [b for b in branches if b.get("source_success") is False and b.get("branch_success") is True]
    print(f"output: {output}")
    print(f"branches: {len(branches)}")
    print(f"replay_faithful_controls: {len(replay_faithful)}")
    print(f"effective_interventions: {len(effective)}")
    if not replay_faithful:
        raise SystemExit("demo failed: no replay-faithful no-intervention control")
    if not effective:
        raise SystemExit("demo failed: no intervention changed the failed outcome")
    print("status: PASS (software semantics only; not scientific model evidence)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
