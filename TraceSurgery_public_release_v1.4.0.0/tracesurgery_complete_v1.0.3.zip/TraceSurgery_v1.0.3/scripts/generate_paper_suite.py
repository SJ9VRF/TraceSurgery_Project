#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, yaml

COUNTS = {
    "browser": 90,
    "documents": 70,
    "spreadsheet": 80,
    "email": 60,
    "filesystem": 50,
    "multi_app": 150,
}


def action(tool, args=None, expected=None, rationale=None):
    d = {"tool": tool, "args": args or {}}
    if expected: d["expected_state_after"] = expected
    if rationale: d["rationale"] = rationale
    return d


def base(task_id, category, instruction, apps, initial, success, script, idx):
    horizon = min(5, 1 + (idx % 5))
    statefulness = min(5, 1 + ((idx // 2) % 5))
    recovery = min(5, 1 + ((idx // 3) % 5))
    return {
        "id": task_id,
        "instruction": instruction,
        "environment": "local",
        "category": category,
        "applications": apps,
        "initial_state": initial,
        "goal_state": {s.get("path", f"goal_{i}"): s.get("equals", s.get("contains")) for i, s in enumerate(success)},
        "success_assertions": success,
        "safety_constraints": [
            {"type": "equals", "path": "_hidden.original_untouched", "equals": True}
        ],
        "max_steps": max(10, len(script) + 4),
        "expected_subgoals": [f"subgoal_{i+1}" for i in range(max(2, min(5, len(script)-1)))],
        "risk_level": "safe",
        "horizon": horizon,
        "statefulness": statefulness,
        "recovery_complexity": recovery,
        "metadata": {
            "script": script,
            "visible_paths": [k for k in initial if not k.startswith("_") and k != "events"],
            "generator_version": "validation-500-v1",
            "template_family": f"{category}_v{idx % 10}",
            "split_group": f"{category}_family_{idx % 10}",
        },
    }


def make_task(category, i):
    n = i + 1
    hidden = {"_hidden": {"original_untouched": True, "answer_key": f"key-{category}-{n}"}}
    if category == "browser":
        initial = {"browser": {"query": "", "results": [], "selected": None, "notes": []}, **hidden}
        script = [
            action("set", {"path":"browser.query","value":f"topic-{n}"}, {"browser.query": f"topic-{n}"}),
            action("set", {"path":"browser.results","value":[f"source-{n}-a",f"source-{n}-b"]}),
            action("set", {"path":"browser.selected","value":f"source-{n}-a"}),
            action("append", {"path":"browser.notes","value":f"fact-{n}"}),
            action("finish")
        ]
        success = [
            {"type":"equals","path":"browser.selected","equals":f"source-{n}-a"},
            {"type":"contains","path":"browser.notes","contains":f"fact-{n}"}
        ]
        instruction = f"Research topic-{n}, select the primary source, and record the verified fact in notes."
        return base(f"browser_{n:03d}", category, instruction, ["browser"], initial, success, script, i)
    if category == "documents":
        initial = {"document": {"title":"Untitled", "sections":[], "saved":False, "path":None}, **hidden}
        script = [
            action("set", {"path":"document.title","value":f"Report {n}"}),
            action("append", {"path":"document.sections","value":{"heading":"Summary","body":f"finding-{n}"}}),
            action("set", {"path":"document.path","value":f"/reports/report_{n:03d}.docx"}),
            action("set", {"path":"document.saved","value":True}),
            action("finish")
        ]
        success = [
            {"type":"equals","path":"document.title","equals":f"Report {n}"},
            {"type":"equals","path":"document.saved","equals":True},
            {"type":"equals","path":"document.path","equals":f"/reports/report_{n:03d}.docx"}
        ]
        return base(f"documents_{n:03d}", category, f"Create Report {n} with a Summary section and save it at the requested path.", ["document"], initial, success, script, i)
    if category == "spreadsheet":
        initial = {"spreadsheet": {"cells":{"A1":n,"A2":n+1,"B1":None}, "formula":None, "saved":False}, **hidden}
        total = 2*n + 1
        script = [
            action("set", {"path":"spreadsheet.formula","value":"=A1+A2"}),
            action("set", {"path":"spreadsheet.cells.B1","value":total}, {"spreadsheet.cells.B1": total}),
            action("set", {"path":"spreadsheet.saved","value":True}),
            action("finish")
        ]
        success = [
            {"type":"equals","path":"spreadsheet.cells.B1","equals":total},
            {"type":"equals","path":"spreadsheet.formula","equals":"=A1+A2"},
            {"type":"equals","path":"spreadsheet.saved","equals":True}
        ]
        return base(f"spreadsheet_{n:03d}", category, f"Calculate A1+A2 into B1 using a formula and save the sheet for case {n}.", ["spreadsheet"], initial, success, script, i)
    if category == "email":
        initial = {"email": {"threads":[{"id":f"t{n}","subject":f"Case {n}","fact":f"detail-{n}"}], "draft":None, "label":None}, **hidden}
        draft = {"thread_id":f"t{n}","body":f"Acknowledged detail-{n}."}
        script = [
            action("set", {"path":"email.draft","value":draft}),
            action("set", {"path":"email.label","value":"processed"}),
            action("finish")
        ]
        success = [
            {"type":"equals","path":"email.draft","equals":draft},
            {"type":"equals","path":"email.label","equals":"processed"}
        ]
        return base(f"email_{n:03d}", category, f"Find Case {n}, draft a factual acknowledgment using its detail, and mark the thread processed.", ["email"], initial, success, script, i)
    if category == "filesystem":
        initial = {"filesystem": {"files":{f"/in/file_{n}.txt":f"payload-{n}"}, "archive":{}}, **hidden}
        script = [
            action("copy", {"src":f"filesystem.files./in/file_{n}.txt","dst":f"filesystem.archive.file_{n}.txt"}),
            action("set", {"path":f"filesystem.files./in/file_{n}.txt","value":f"payload-{n}"}),
            action("finish")
        ]
        # dotted keys make get_path unsuitable, so use nested clean source keys instead
        initial = {"filesystem": {"inbox":{f"file_{n}":f"payload-{n}"}, "archive":{}}, **hidden}
        script = [
            action("copy", {"src":f"filesystem.inbox.file_{n}","dst":f"filesystem.archive.file_{n}"}),
            action("finish")
        ]
        success = [{"type":"equals","path":f"filesystem.archive.file_{n}","equals":f"payload-{n}"}]
        return base(f"filesystem_{n:03d}", category, f"Archive file_{n} without changing the source payload.", ["files"], initial, success, script, i)
    if category == "multi_app":
        initial = {
            "browser": {"sources":[{"name":f"paper-{n}-a","year":2024},{"name":f"paper-{n}-b","year":2025}], "selected":None},
            "spreadsheet": {"rows":[], "saved":False},
            "document": {"paragraphs":[], "saved":False},
            **hidden,
        }
        row1 = {"name":f"paper-{n}-a","year":2024}
        row2 = {"name":f"paper-{n}-b","year":2025}
        script = [
            action("set", {"path":"browser.selected","value":f"paper-{n}-a"}),
            action("append", {"path":"spreadsheet.rows","value":row1}),
            action("append", {"path":"spreadsheet.rows","value":row2}),
            action("set", {"path":"spreadsheet.saved","value":True}),
            action("append", {"path":"document.paragraphs","value":f"paper-{n}-b is newer than paper-{n}-a."}),
            action("set", {"path":"document.saved","value":True}),
            action("finish")
        ]
        success = [
            {"type":"contains","path":"spreadsheet.rows","contains":row1},
            {"type":"contains","path":"spreadsheet.rows","contains":row2},
            {"type":"equals","path":"spreadsheet.saved","equals":True},
            {"type":"contains","path":"document.paragraphs","contains":f"paper-{n}-b is newer than paper-{n}-a."},
            {"type":"equals","path":"document.saved","equals":True}
        ]
        return base(f"multi_app_{n:03d}", category, f"Compare the two provided papers, enter their metadata in the sheet, write which is newer in the document, and save both.", ["browser","spreadsheet","document"], initial, success, script, i)
    raise ValueError(category)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default="tasks/validation_500")
    ap.add_argument("--suite", default="tasks/suites/validation_500.yaml")
    args = ap.parse_args()
    root = Path(args.root)
    suite_path = Path(args.suite)
    root.mkdir(parents=True, exist_ok=True)
    suite_path.parent.mkdir(parents=True, exist_ok=True)
    refs=[]
    for category, count in COUNTS.items():
        cdir = root/category
        cdir.mkdir(parents=True, exist_ok=True)
        for i in range(count):
            task=make_task(category,i)
            path=cdir/f"{task['id']}.yaml"
            path.write_text(yaml.safe_dump(task, sort_keys=False), encoding="utf-8")
            refs.append(str(Path("..") / "validation_500" / category / path.name))
    suite_path.write_text(yaml.safe_dump({"name":"tracesurgery-validation-500","tasks":refs}, sort_keys=False), encoding="utf-8")
    print(f"generated {len(refs)} tasks")

if __name__ == "__main__":
    main()
