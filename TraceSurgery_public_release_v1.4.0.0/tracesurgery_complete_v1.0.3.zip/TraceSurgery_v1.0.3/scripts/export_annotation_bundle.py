#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from tracesurgery.io import read_results

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--output", required=True)
    ap.add_argument("--limit", type=int, default=0)
    args=ap.parse_args()
    trials=read_results(args.results)
    rows=[]
    for t in trials:
        for s in t.trajectory:
            rows.append({
                "trial_id":t.trial_id,"task_id":t.task_id,"agent":t.agent,"model":t.model,"step":s.step,
                "observation":s.observation.model_dump(),"action":s.action.model_dump(),
                "state_delta":s.state_delta,"perturbations_applied":s.perturbations_applied,"blocked":s.blocked,
            })
            if args.limit and len(rows)>=args.limit: break
        if args.limit and len(rows)>=args.limit: break
    p=Path(args.output);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text("\n".join(json.dumps(r) for r in rows)+"\n")
    print(json.dumps({"steps":len(rows),"output":str(p)},indent=2))
if __name__=="__main__":main()
