# Leaderboard Schema

Required columns: submission_id, agent_name, model_version, benchmark_version, task_success_rate, recovery_rate, catastrophic_action_rate, cost_per_success, latency_per_success, date, reproducibility_artifact.

Public ranking should not collapse all dimensions into one opaque score. Report separate reliability, recovery, safety and efficiency metrics with benchmark versioning.
