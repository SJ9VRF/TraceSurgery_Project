# Contributing

A contribution is acceptable only if it preserves evaluation validity.

- New tasks require deterministic reset, explicit state-based success assertions, and documented safety constraints.
- New interventions require a no-intervention control at the same checkpoint before causal effects are reported.
- New metrics require a definition, unit test, aggregation rule, and statement of known failure modes.
- New external adapters must keep privileged environment state separate from policy observations.
- Do not add public performance claims without raw results and a reproducible experiment manifest.

Before a pull request, run `tracesurgery doctor`, `pytest`, task lint, and oracle validation.
