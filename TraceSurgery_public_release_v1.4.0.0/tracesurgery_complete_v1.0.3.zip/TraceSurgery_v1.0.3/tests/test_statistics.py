from tracesurgery.statistics import wilson_interval,success_at_k,task_cluster_bootstrap,paired_task_bootstrap

def test_wilson_and_success_at_k():
    lo,hi=wilson_interval(5,10); assert 0<lo<.5<hi<1
    assert success_at_k({'a':[False,True],'b':[False,False]},2)==.5

def test_cluster_bootstrap_is_task_level():
    rows=[{'task_id':'a','m':1},{'task_id':'a','m':1},{'task_id':'b','m':0}]
    x=task_cluster_bootstrap(rows,'m',100,0); assert x['mean']==.5 and x['n_tasks']==2
    y=paired_task_bootstrap([{'task_id':'a','m':0},{'task_id':'b','m':0}],[{'task_id':'a','m':1},{'task_id':'b','m':0}],'m',100,0)
    assert y['delta']==.5
