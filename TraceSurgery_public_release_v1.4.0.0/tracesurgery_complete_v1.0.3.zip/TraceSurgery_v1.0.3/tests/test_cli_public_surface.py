import json
import sys
from pathlib import Path

import pytest

from tracesurgery.cli import main

ROOT = Path(__file__).resolve().parents[1]


def invoke(monkeypatch, *args, exit_code=None):
    monkeypatch.setattr(sys, "argv", ["tracesurgery", *map(str, args)])
    if exit_code is None:
        return main()
    with pytest.raises(SystemExit) as exc:
        main()
    assert exc.value.code == exit_code


def test_cli_validation_lint_doctor_and_perturbations(monkeypatch, capsys):
    suite = ROOT / "tasks/suites/mvp.yaml"
    invoke(monkeypatch, "lint-suite", "--suite", suite, exit_code=0)
    assert json.loads(capsys.readouterr().out)["valid"] is True

    invoke(monkeypatch, "validate-suite", "--suite", suite, "--oracle-run", exit_code=0)
    report = json.loads(capsys.readouterr().out)
    assert report["valid"] is True
    assert report["oracle_failures"] == []

    invoke(monkeypatch, "doctor", exit_code=0)
    assert json.loads(capsys.readouterr().out)["ok"] is True

    invoke(monkeypatch, "list-perturbations")
    assert capsys.readouterr().out.strip()


def test_cli_run_analyze_and_surgery(monkeypatch, capsys, tmp_path):
    suite = ROOT / "tasks/suites/mvp.yaml"
    run_dir = tmp_path / "run"
    invoke(monkeypatch, "run", "--suite", suite, "--agent", "scripted", "--trials", "1", "--output", run_dir)
    run_report = json.loads(capsys.readouterr().out)
    assert Path(run_report["results"]).exists()
    assert Path(run_report["manifest"]).exists()

    summary_path = tmp_path / "summary.json"
    invoke(monkeypatch, "analyze", run_report["results"], "--output", summary_path)
    summary = json.loads(capsys.readouterr().out)
    assert summary["n_trials"] >= 1
    assert summary_path.exists()

    surgery_path = tmp_path / "surgery.json"
    invoke(monkeypatch, "surgery", "--task", ROOT / "tasks/samples/spreadsheet_formula.yaml", "--output", surgery_path)
    surgery_report = json.loads(capsys.readouterr().out)
    assert surgery_report["baseline_success"] is False
    assert surgery_report["oracle_success"] is True
    assert surgery_path.exists()


def test_cli_study_lifecycle(monkeypatch, capsys, tmp_path):
    study_dir = tmp_path / "study"
    invoke(monkeypatch, "study-init", "--config", ROOT / "configs/external_study.example.yaml", "--output", study_dir)
    init = json.loads(capsys.readouterr().out)
    assert init["n_runs"] > 0
    ledger = Path(init["ledger"])

    invoke(monkeypatch, "study-status", "--ledger", ledger)
    status = json.loads(capsys.readouterr().out)
    assert status["status"]["pending"] == init["n_runs"]

    invoke(monkeypatch, "study-claim", "--ledger", ledger, "--worker", "pytest-worker")
    claimed = json.loads(capsys.readouterr().out)
    assert claimed["status"] == "running"
    assert claimed["worker_id"] == "pytest-worker"

    result_path = tmp_path / "result.json"
    result_path.write_text("{}\n")
    invoke(monkeypatch, "study-mark", "--ledger", ledger, "--run-id", claimed["run_id"], "--status", "complete", "--result-path", result_path)
    marked = json.loads(capsys.readouterr().out)
    assert marked["status"] == "complete"


def test_cli_release_audit(monkeypatch, capsys, tmp_path):
    out = tmp_path / "audit.json"
    invoke(monkeypatch, "release-audit", "--root", ROOT, "--output", out, exit_code=0)
    report = json.loads(capsys.readouterr().out)
    assert report["ok"] is True
    assert out.exists()


def test_cli_version(monkeypatch, capsys):
    invoke(monkeypatch, "--version", exit_code=0)
    assert capsys.readouterr().out.strip() == "tracesurgery 1.0.3"
