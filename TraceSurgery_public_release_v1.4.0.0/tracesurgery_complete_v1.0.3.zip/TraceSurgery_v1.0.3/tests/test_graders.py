from tracesurgery.core.models import AssertionSpec
from tracesurgery.graders.assertions import evaluate_assertion

def test_equals_and_contains():
    state={"a":{"b":"hello world"}}
    assert evaluate_assertion(state, AssertionSpec(type="equals",path="a.b",equals="hello world"))[0]
    assert evaluate_assertion(state, AssertionSpec(type="contains",path="a.b",contains="world"))[0]
