from tracesurgery.evidence import EvidenceRecord, evidence_audit


def test_local_validation_is_rejected_as_scientific_evidence():
    r = EvidenceRecord(run_id="r1", study_id="s", task_id="t", model_id="m", environment_id="local", benchmark="validation", seed=0, success=True, source="local_validation")
    report = evidence_audit([r])
    assert not report["ok"]
    assert report["n_eligible_for_performance_claims"] == 0


def test_external_record_with_provenance_is_eligible():
    r = EvidenceRecord(run_id="r1", study_id="s", task_id="t", model_id="m", model_revision="rev", environment_id="osworld", benchmark="OSWorld", benchmark_version="x", seed=0, success=False, source="external_execution", manifest_path="manifest.json", manifest_sha256="abc", grader_version="g1", replay_admissible=True)
    report = evidence_audit([r])
    assert report["ok"]
    assert report["eligible_run_ids"] == ["r1"]


def test_file_verification_catches_fake_manifest_hash(tmp_path):
    from tracesurgery.evidence import sha256_file
    p=tmp_path/"manifest.json"; p.write_text('{}\n')
    r = EvidenceRecord(run_id="r2", study_id="s", task_id="t", model_id="m", model_revision="rev", environment_id="osworld", benchmark="OSWorld", benchmark_version="2", seed=0, success=True, source="external_execution", manifest_path="manifest.json", manifest_sha256="deadbeef", grader_version="g1", replay_admissible=True)
    report=evidence_audit([r],base_dir=tmp_path,verify_files=True)
    assert not report["ok"]
    assert "manifest_hash_mismatch" in report["errors"][0]["reasons"]
