from tracesurgery.perturbations.library import REGISTRY

def test_twenty_perturbations_are_reproducible_callables():
    assert len(REGISTRY) >= 20
    for name, factory in REGISTRY.items():
        state={"events":[]}
        p=factory(step=2)
        assert not p.maybe_apply(state,1)
        assert p.maybe_apply(state,2)
        assert state["events"][-1]["name"] == p.name
