from tracesurgery.io import load_task
from tracesurgery.environments.local import LocalSandbox
from tracesurgery.runners.runner import TrialRunner
from tracesurgery.agents.scripted import ScriptedAgent, FaultyScriptedAgent
from tracesurgery.counterfactual import CounterfactualSurgeon, SurgeryKind


def test_counterfactual_action_patch_localizes_injected_error():
    task = load_task('tasks/samples/spreadsheet_formula.yaml')
    runner = TrialRunner(LocalSandbox())
    oracle = runner.run(task, ScriptedAgent(), seed=0)
    failed = runner.run(task, FaultyScriptedAgent(), seed=0)
    assert oracle.success is True
    assert failed.success is False

    surgeon = CounterfactualSurgeon(LocalSandbox())
    surface = surgeon.sweep(task, failed, oracle)
    action_repairs = surface.by_kind(SurgeryKind.ACTION_PATCH)
    successful_steps = [b.intervention_step for b in action_repairs if b.success]
    assert successful_steps == [0]
    assert surface.recovery_auc(SurgeryKind.ACTION_PATCH) == 0.5


def test_state_patch_recovers_after_corruption():
    task = load_task('tasks/samples/spreadsheet_formula.yaml')
    runner = TrialRunner(LocalSandbox())
    oracle = runner.run(task, ScriptedAgent(), seed=0)
    failed = runner.run(task, FaultyScriptedAgent(), seed=0)
    surgeon = CounterfactualSurgeon(LocalSandbox())
    # At step 1, swapping in the oracle pre-state repairs the earlier corruption.
    b = surgeon.branch(task, failed, step=1, kind=SurgeryKind.STATE_PATCH, oracle_trial=oracle)
    assert b.success is True
    assert b.outcome_gain == 1


def test_no_intervention_replay_preserves_failure():
    task = load_task('tasks/samples/spreadsheet_formula.yaml')
    runner = TrialRunner(LocalSandbox())
    oracle = runner.run(task, ScriptedAgent(), seed=0)
    failed = runner.run(task, FaultyScriptedAgent(), seed=0)
    surface = CounterfactualSurgeon(LocalSandbox()).sweep(task, failed, oracle)
    controls = surface.by_kind(SurgeryKind.NO_INTERVENTION)
    assert controls
    assert all(b.success is False for b in controls)


def test_replay_fidelity_gates_causal_branches():
    task = load_task('tasks/samples/spreadsheet_formula.yaml')
    runner = TrialRunner(LocalSandbox())
    oracle = runner.run(task, ScriptedAgent(), seed=0)
    failed = runner.run(task, FaultyScriptedAgent(), seed=0)
    surface = CounterfactualSurgeon(LocalSandbox()).sweep(task, failed, oracle)
    assert all(surface.control_fidelity_by_step().values())
    assert surface.admissible_steps() == [0, 1]
    assert all(b.causally_usable for b in surface.by_kind(SurgeryKind.ACTION_PATCH))


def test_diagnosis_faithfulness_requires_executed_effect():
    from tracesurgery.counterfactual import DiagnosisClaim
    task = load_task('tasks/samples/spreadsheet_formula.yaml')
    runner = TrialRunner(LocalSandbox())
    oracle = runner.run(task, ScriptedAgent(), seed=0)
    failed = runner.run(task, FaultyScriptedAgent(), seed=0)
    surgeon = CounterfactualSurgeon(LocalSandbox())
    result = surgeon.diagnosis_faithfulness(task, failed, oracle, [
        DiagnosisClaim(step=0, repair_kind=SurgeryKind.ACTION_PATCH, label='true'),
        DiagnosisClaim(step=1, repair_kind=SurgeryKind.ACTION_PATCH, label='plausible-but-wrong'),
    ])
    assert result['n_evaluable'] == 2
    assert result['faithfulness'] == 0.5
    assert result['claims'][0]['faithful'] is True
    assert result['claims'][1]['faithful'] is False


def test_minimum_action_repair_search_is_executable():
    task = load_task('tasks/samples/spreadsheet_formula.yaml')
    runner = TrialRunner(LocalSandbox())
    oracle = runner.run(task, ScriptedAgent(), seed=0)
    failed = runner.run(task, FaultyScriptedAgent(), seed=0)
    out = CounterfactualSurgeon(LocalSandbox()).minimal_action_repair_sets(
        task, failed, oracle, candidate_steps=[0, 1], max_edits=2
    )
    assert out
    assert out[0]['n_edits'] == 1
    assert out[0]['steps'] == [0]


def test_sweep_always_serializes_replay_controls():
    task = load_task('tasks/samples/spreadsheet_formula.yaml')
    runner = TrialRunner(LocalSandbox())
    oracle = runner.run(task, ScriptedAgent(), seed=0)
    failed = runner.run(task, FaultyScriptedAgent(), seed=0)
    surface = CounterfactualSurgeon(LocalSandbox()).sweep(
        task, failed, oracle, kinds=(SurgeryKind.ACTION_PATCH,)
    )
    assert len(surface.by_kind(SurgeryKind.NO_INTERVENTION)) == 2
    assert surface.admissible_steps() == [0, 1]
