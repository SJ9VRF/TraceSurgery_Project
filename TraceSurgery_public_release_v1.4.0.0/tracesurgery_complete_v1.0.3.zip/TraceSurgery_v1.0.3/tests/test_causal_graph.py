from tracesurgery.core.models import FailureEvent, FailureType, CausalEdge
from tracesurgery.failures.causal_graph import CausalFailureGraph

def test_graph_depth():
    es=[FailureEvent(id="F1",step=1,type=FailureType.grounding_element,root_cause=True),FailureEvent(id="F2",step=2,type=FailureType.state_assumption),FailureEvent(id="F3",step=3,type=FailureType.verification_missed)]
    g=CausalFailureGraph(es,[CausalEdge(source="F1",target="F2"),CausalEdge(source="F2",target="F3")])
    assert g.root_failures()==["F1"]
    assert g.propagation_depth("F1")==2
    assert g.cascade_size("F1")==2
