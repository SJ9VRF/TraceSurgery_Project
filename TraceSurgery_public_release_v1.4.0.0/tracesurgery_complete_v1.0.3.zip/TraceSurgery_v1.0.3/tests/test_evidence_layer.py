from pathlib import Path
import csv, json

ROOT = Path(__file__).resolve().parents[1]


def test_evidence_layer_has_grounded_counts():
    lines = [json.loads(x) for x in (ROOT / "artifacts/experiment_logs/experiment_journal.jsonl").read_text().splitlines() if x.strip()]
    assert len(lines) == 9
    assert sum(x["kind"] == "local_causal" for x in lines) == 8
    assert sum(x["kind"] == "software_validation" for x in lines) == 1


def test_local_eval_table_matches_raw_demo():
    demo = json.loads((ROOT / "runs/demo_5min.json").read_text())
    with (ROOT / "artifacts/eval_runs/local_demo_eval.csv").open() as f:
        rows = {r["variant"]: r for r in csv.DictReader(f)}
    for kind in ["no_intervention", "action_patch", "state_patch", "suffix_replan"]:
        raw = [b for b in demo["branches"] if b["kind"] == kind]
        assert int(rows[kind]["checkpoints"]) == len(raw) == 2
        assert int(rows[kind]["recoveries"]) == sum(bool(b["success"]) for b in raw)


def test_evidence_layer_does_not_populate_external_results():
    text = (ROOT / "artifacts/eval_runs/EXTERNAL_RESULTS_PENDING.md").read_text().lower()
    assert "pending" in text
    assert "no frontier-model comparison is populated" in text
