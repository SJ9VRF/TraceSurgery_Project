from tracesurgery.external import adapter_conformance

class Bad: pass

def test_bad_adapters_fail_conformance():
    assert not adapter_conformance(provider=Bad())["ok"]
