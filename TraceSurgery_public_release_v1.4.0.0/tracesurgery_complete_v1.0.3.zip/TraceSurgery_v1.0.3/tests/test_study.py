from pathlib import Path
from tracesurgery.study import StudySpec, ModelSpec, EnvironmentSpec, expand_study, RunLedger


def _spec():
    return StudySpec(
        study_id="s1",
        task_ids=["t1", "t2"],
        models=[ModelSpec(id="m1", provider="p", model="x", adapter="a")],
        environments=[EnvironmentSpec(id="e1", adapter="env", benchmark="bench")],
        seeds=[0, 1], repetitions=2,
    )


def test_expand_is_deterministic_and_unique():
    a = expand_study(_spec()); b = expand_study(_spec())
    assert [x.run_id for x in a] == [x.run_id for x in b]
    assert len(a) == 8 and len({x.run_id for x in a}) == 8


def test_ledger_resume(tmp_path: Path):
    p = tmp_path / "ledger.jsonl"
    ledger = RunLedger(p); ledger.initialize(_spec())
    first = ledger.claim_next(); assert first and first.status == "running" and first.attempt == 1
    ledger.update(first.run_id, status="complete", result_path="r.json")
    second = ledger.claim_next(); assert second and second.run_id != first.run_id
    summary = ledger.summary(); assert summary["status"]["complete"] == 1


def test_claim_records_worker_and_mark_helpers(tmp_path: Path):
    ledger=RunLedger(tmp_path/"ledger.jsonl"); ledger.initialize(_spec())
    row=ledger.claim_next(worker_id="worker-7",retry_failed=False)
    assert row is not None and row.worker_id=="worker-7" and row.attempt==1
    done=ledger.mark_complete(row.run_id,"results/r.json")
    assert done.status=="complete" and done.result_path=="results/r.json"


def test_study_and_ledger_schema_versions():
    from tracesurgery.study import StudySpec, ModelSpec, EnvironmentSpec, expand_study
    spec = StudySpec(study_id="schema", task_ids=["t"], models=[ModelSpec(id="m", provider="p", model="x", adapter="a")], environments=[EnvironmentSpec(id="e", adapter="a", benchmark="b")])
    assert spec.schema_version == "1.0"
    assert expand_study(spec)[0].schema_version == "1.0"
