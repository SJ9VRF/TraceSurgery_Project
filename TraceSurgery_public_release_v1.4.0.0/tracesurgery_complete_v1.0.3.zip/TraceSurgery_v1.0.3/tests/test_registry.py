from pathlib import Path
from tracesurgery.registry import make_manifest, write_manifest, manifest_fingerprint
from tracesurgery.doctor import run_doctor


def test_manifest_is_written_and_fingerprinted(tmp_path):
    suite = tmp_path / "suite.yaml"
    suite.write_text("tasks: []\n")
    m = make_manifest(project_version="test", suite_path=str(suite), task_count=0, agent="x", trials=1, environment="local")
    out = write_manifest(tmp_path / "manifest.json", m)
    assert out.exists()
    assert len(manifest_fingerprint(m)) >= 32
    assert m.suite_sha256 is not None


def test_doctor_reports_required_repo_assets():
    report = run_doctor(Path(__file__).parents[1])
    assert report["ok"] is True
    assert report["checks"]["validation_suite_present"] is True
