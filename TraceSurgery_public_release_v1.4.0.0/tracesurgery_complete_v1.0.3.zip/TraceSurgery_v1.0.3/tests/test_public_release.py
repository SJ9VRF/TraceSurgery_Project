import json
import subprocess
import sys
from pathlib import Path

import tracesurgery.release_audit as ra


def test_demo_entrypoint_runs_and_produces_auditable_branches(tmp_path):
    output = tmp_path / "demo.json"
    proc = subprocess.run(
        [sys.executable, "scripts/demo_5min.py", "--output", str(output)],
        text=True,
        capture_output=True,
    )
    assert proc.returncode == 0, proc.stdout + proc.stderr
    assert "status: PASS" in proc.stdout
    data = json.loads(output.read_text())
    assert data["branches"]
    assert any(b["kind"] == "no_intervention" and b["replay_matches_source"] is True for b in data["branches"])
    assert any(b["outcome_gain"] == 1 for b in data["branches"])


def test_release_audit_flags_generated_build_tree(tmp_path, monkeypatch):
    monkeypatch.setattr(ra, "REQUIRED_ARTIFACTS", [])
    monkeypatch.setattr(ra, "PUBLIC_FILES", [])
    (tmp_path / "build/lib").mkdir(parents=True)
    (tmp_path / "build/lib/generated.py").write_text("x=1")
    report = ra.audit(tmp_path)
    assert report["n_warnings"] == 1
    assert report["warnings"][0]["check"] == "release_hygiene"
