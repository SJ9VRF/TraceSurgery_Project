from pathlib import Path
from tracesurgery.release_audit import audit


def test_release_audit_has_no_errors():
    report = audit(Path(__file__).resolve().parents[1])
    assert report["n_errors"] == 0, report
    assert report["author"] == "Aura Yavary"
