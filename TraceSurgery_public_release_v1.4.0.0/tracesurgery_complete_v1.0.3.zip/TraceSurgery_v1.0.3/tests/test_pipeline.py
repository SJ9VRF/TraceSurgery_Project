from tracesurgery.io import load_suite
from tracesurgery.environments.local import LocalSandbox
from tracesurgery.agents.scripted import ScriptedAgent, FaultyScriptedAgent
from tracesurgery.runners.runner import TrialRunner

def test_scripted_mvp_passes():
    tasks=load_suite("tasks/suites/mvp.yaml")
    runner=TrialRunner(LocalSandbox())
    results=[runner.run(t, ScriptedAgent()) for t in tasks]
    assert all(r.success for r in results)

def test_faulty_agent_fails_formula_task():
    tasks=load_suite("tasks/suites/mvp.yaml")
    t=[x for x in tasks if x.id=="spreadsheet_formula_001"][0]
    r=TrialRunner(LocalSandbox()).run(t, FaultyScriptedAgent())
    assert not r.success

def test_hidden_state_not_exposed_to_agent():
    t=load_suite("tasks/suites/validation_500.yaml")[0]
    env=LocalSandbox()
    obs=env.reset(t, 0)
    assert "_hidden" not in obs.visible_state
    assert "events" not in obs.visible_state

def test_safety_gate_blocks_diagnostic_destructive_action():
    from tracesurgery.agents.baselines import UnsafeDiagnosticAgent
    t=load_suite("tasks/suites/validation_500.yaml")[0]
    t.metadata["safety_mode"]="enforce"
    r=TrialRunner(LocalSandbox()).run(t, UnsafeDiagnosticAgent())
    assert r.trajectory[0].blocked
    assert not r.success
    assert any(f.type.value == "safety.irreversible_action" for f in r.failure_events)

def test_repeating_agent_produces_recovery_pathology():
    from tracesurgery.agents.baselines import RepeatingFailureAgent
    t=load_suite("tasks/suites/validation_500.yaml")[0]
    r=TrialRunner(LocalSandbox()).run(t, RepeatingFailureAgent())
    assert not r.success
    assert any(f.type.value == "recovery.repeated_failed_action" for f in r.failure_events)
