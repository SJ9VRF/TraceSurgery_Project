from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parents[1]

def _load():
    path = ROOT / "scripts/verify_evidence_layer.py"
    spec = importlib.util.spec_from_file_location("verify_evidence_layer", path)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod

def test_claim_ledger_matches_raw_evidence():
    report = _load().verify(ROOT)
    assert report["ok"], report
    assert all(report["checks"].values())

def test_claim_ledger_has_machine_readable_entries():
    import json
    ledger = json.loads((ROOT / "artifacts/claim_ledger.json").read_text())
    ids = [x["id"] for x in ledger["claims"]]
    assert ids == [f"TS-C{i:03d}" for i in range(1, 10)]
