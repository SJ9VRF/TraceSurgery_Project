from tracesurgery.core.models import Task,AssertionSpec,Action
from tracesurgery.environments.local import LocalSandbox
from tracesurgery.runners.runner import TrialRunner
from tracesurgery.agents.base import Agent

class BeliefAgent(Agent):
    name='belief'; model='test'
    def act(self,obs,step):
        if step==0:return Action(tool='set',args={'path':'x','value':2},belief_state={'x':999},expected_state_after={'x':2})
        return Action(tool='finish',completion_claim=True)

def task():
    return Task(id='t',instruction='set x',initial_state={'x':1,'_hidden':{'secret':7}},
        success_assertions=[AssertionSpec(type='equals',path='x',equals=2)],metadata={'visible_paths':['x']})

def test_pre_action_observation_and_hidden_state_separation():
    r=TrialRunner(LocalSandbox()).run(task(),BeliefAgent())
    s=r.trajectory[0]
    assert s.observation.visible_state=={'x':1}
    assert s.post_observation.visible_state=={'x':2}
    assert '_hidden' not in s.observation.visible_state
    assert s.belief_mismatches[0]['actual']==1

def test_intervention_not_automatically_agent_failure():
    class P:
        name='external-change'
        def maybe_apply(self,state,step):
            if step==0: state['noise']=1; return True
            return False
    r=TrialRunner(LocalSandbox()).run(task(),BeliefAgent(),perturbations=[P()])
    assert len(r.interventions)==1
    assert all(f.attribution!='environment' for f in r.failure_events)
