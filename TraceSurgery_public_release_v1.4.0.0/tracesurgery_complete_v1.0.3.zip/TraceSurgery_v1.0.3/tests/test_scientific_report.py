from pathlib import Path
import json
import pytest

from tracesurgery.evidence import EvidenceRecord, write_evidence, sha256_file
from tracesurgery.scientific_report import write_report


def _record(run_id, model_id, task_id, manifest, success):
    return EvidenceRecord(
        run_id=run_id, study_id="s", task_id=task_id, model_id=model_id,
        model_revision="rev1", environment_id="osworld", benchmark="OSWorld",
        benchmark_version="2.0", seed=0, success=success, source="external_execution",
        manifest_path=manifest.name, manifest_sha256=sha256_file(manifest), grader_version="g1",
        replay_admissible=True, human_audited=True, recovery_auc=0.5,
    )


def test_guarded_report_writes_paper_ready_artifacts(tmp_path: Path):
    manifest=tmp_path/"manifest.json"; manifest.write_text('{"x":1}\n')
    records=[
        _record("a1","model-a","t1",manifest,True),
        _record("a2","model-a","t2",manifest,False),
        _record("b1","model-b","t1",manifest,True),
        _record("b2","model-b","t2",manifest,True),
    ]
    ep=write_evidence(tmp_path/"evidence.jsonl",records)
    report=write_report(ep,tmp_path/"report",bootstrap_seed=1)
    assert report["audit"]["ok"]
    for name in ["scientific_summary.json","evidence_audit.json","model_summary.csv","model_summary.md","model_summary.tex"]:
        assert (tmp_path/"report"/name).exists()


def test_report_refuses_bad_manifest_hash(tmp_path: Path):
    manifest=tmp_path/"manifest.json"; manifest.write_text('{}\n')
    r=_record("a1","model-a","t1",manifest,True)
    r.manifest_sha256="0"*64
    ep=write_evidence(tmp_path/"evidence.jsonl",[r])
    with pytest.raises(ValueError):
        write_report(ep,tmp_path/"report")
