from pathlib import Path

from tracesurgery.core.models import AssertionSpec, Task, RiskLevel
from tracesurgery.core.utils import delete_path, get_path, project_state, set_path, state_diff
from tracesurgery.graders.assertions import evaluate_assertion
from tracesurgery.task_lint import lint_task, lint_suite
from tracesurgery.io import load_task, write_results
from tracesurgery.runners.runner import TrialRunner
from tracesurgery.environments.local import LocalSandbox
from tracesurgery.agents.scripted import ScriptedAgent, FaultyScriptedAgent
from tracesurgery.analysis import summarize


def _spec(kind, **kwargs):
    return AssertionSpec(type=kind, **kwargs)


def test_all_assertion_operators_and_failure_paths():
    state = {"s": {"text": "hello 123", "n": 3.01, "items": ["a", "b", "c"], "present": 1}}
    cases = [
        (_spec("equals", path="s.present", equals=1), True),
        (_spec("contains", path="s.text", contains="123"), True),
        (_spec("exists", path="s.present"), True),
        (_spec("not_exists", path="s.missing"), True),
        (_spec("not_contains", path="s.text", contains="zzz"), True),
        (_spec("approx", path="s.n", equals=3.0, value=0.02), True),
        (_spec("regex", path="s.text", contains=r"hello\s+\d+"), True),
        (_spec("length", path="s.items", value=3), True),
        (_spec("subset", path="s.items", value=["a", "c"]), True),
        (_spec("approx", path="s.text", equals=3.0, value=0.1), False),
        (_spec("length", path="s.present", value=2), False),
        (_spec("subset", path="s.present", value=[1]), False),
        (_spec("unknown", path="s.present"), False),
    ]
    for spec, expected in cases:
        ok, detail = evaluate_assertion(state, spec)
        assert ok is expected
        assert detail["type"] == spec.type


def test_state_path_projection_and_diff_do_not_leak_private_state():
    state = {"public": {"x": 1, "y": 2}, "_hidden": {"answer": 42}, "events": [1]}
    assert get_path(state, "public.x") == 1
    assert get_path(state, "public.nope", "fallback") == "fallback"
    set_path(state, "public.deep.z", 9)
    assert state["public"]["deep"]["z"] == 9
    delete_path(state, "public.deep.z")
    assert get_path(state, "public.deep.z") is None
    assert project_state(state) == {"public": {"x": 1, "y": 2, "deep": {}}}
    assert project_state(state, ["public.x"]) == {"public": {"x": 1}}
    diff = state_diff({"a": 1, "b": 2}, {"a": 3, "c": 4})
    assert diff == {
        "a": {"before": 1, "after": 3},
        "b": {"before": 2, "after": None},
        "c": {"before": None, "after": 4},
    }


def _task(task_id="t", **overrides):
    data = dict(
        id=task_id,
        instruction="do it",
        success_assertions=[AssertionSpec(type="equals", path="x", equals=1)],
        max_steps=4,
        horizon=1,
    )
    data.update(overrides)
    return Task(**data)


def test_task_lint_detects_release_relevant_problems():
    t = _task(
        instruction=" ",
        max_steps=1,
        horizon=1,
        risk_level=RiskLevel.high,
        success_assertions=[
            AssertionSpec(type="equals", path="_hidden.answer", equals=42),
            AssertionSpec(type="equals", path="_hidden.answer", equals=42),
        ],
        metadata={"visible_paths": ["_hidden.answer"], "scripted_actions": "not-a-list"},
    )
    codes = {i["code"] for i in lint_task(t)}
    assert {"empty_instruction", "tight_budget", "duplicate_success_assertion", "hidden_state_leak", "missing_safety_assertion", "bad_oracle"} <= codes

    report = lint_suite([_task("dup"), _task("dup")])
    assert not report["valid"]
    assert report["issues"]["__suite__"][0]["code"] == "duplicate_ids"


def test_analysis_summary_is_task_clustered_and_serialized(tmp_path):
    task = load_task(Path("tasks/samples/spreadsheet_formula.yaml"))
    runner = TrialRunner(LocalSandbox())
    results = [
        runner.run(task, ScriptedAgent(), seed=0),
        runner.run(task, FaultyScriptedAgent(), seed=1),
    ]
    results_path = tmp_path / "results.jsonl"
    summary_path = tmp_path / "summary.json"
    write_results(results_path, results)
    summary = summarize(results_path, summary_path, bootstrap_seed=7)
    assert summary["n_trials"] == 2
    assert summary["n_tasks"] == 1
    assert summary["ci_unit"] == "task"
    assert set(summary["by_agent"]) == {"faulty-scripted", "scripted"}
    assert summary_path.exists()
