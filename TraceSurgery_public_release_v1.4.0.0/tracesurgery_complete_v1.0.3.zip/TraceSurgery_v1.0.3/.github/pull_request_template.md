## Summary

What does this change do and why is it needed?

## Evidence

- [ ] Tests added or updated where behavior changed
- [ ] `python scripts/verify_release.py` passes locally, or limitations are explained below
- [ ] No API keys, private traces, or proprietary model outputs are committed

## Evaluation-validity checklist

- [ ] Agent-visible observations remain separated from evaluator-only state
- [ ] New interventions include a same-checkpoint no-intervention control before causal effects are reported
- [ ] New metrics define their statistical unit and aggregation rule
- [ ] New public performance claims point to auditable external evidence records
- [ ] Changes to schemas document compatibility or migration behavior

## Limitations / unresolved risks

Describe any remaining validity, reproducibility, or compatibility risks.
