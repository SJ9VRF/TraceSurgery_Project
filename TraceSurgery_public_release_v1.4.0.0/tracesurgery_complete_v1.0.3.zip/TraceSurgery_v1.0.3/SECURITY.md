# Security

TraceSurgery is an evaluation framework for agents that may operate stateful environments. Do not point untrusted or experimental policies at accounts, payment surfaces, production files, credentials, or irreversible external actions.

The reference local environment is a sandbox. External environment adapters should default to isolated test accounts and reversible actions. High-risk actions must be separately audited or explicitly enforced through the safety mode; benchmark scoring must record safety violations rather than silently hiding them.

Never commit API keys, session cookies, access tokens, private user data, or raw production trajectories containing secrets. Experiment manifests record only whether selected credential variables are present, not their values.
