# TraceSurgery project page specification

## Hero
**TraceSurgery** — Diagnosing when, why and how long-horizon agents fail — and whether they can still recover.

Primary CTA: Paper · Code · Data · Explorer

## 30-second result
Reserve this panel for measured paper results only. Before experiments, show the methodology visual rather than placeholder percentages.

## Required sections
1. Problem: terminal error is not root cause.
2. Key insight: failures have causal structure and time-limited recovery opportunities.
3. Benchmark: task categories + horizon/statefulness/recovery axes.
4. Method: trajectory → failure events → causal graph → recoverability.
5. Results: real plots only.
6. Ablations / reliability checks.
7. Failure cases and negative results.
8. Interactive trajectory explorer.
9. My contribution.
10. Resources: paper/code/data/demo/report.

## Primary visuals
- Sankey: root failure → recoverable/unrecoverable → recovered/cascade/catastrophic.
- Recovery survival curve: P(successful recovery) vs steps since first failure.
- Horizon degradation plot: task success and state divergence vs horizon.
- Causal failure graph for a representative trajectory.
