# Failure Annotation Guide

Annotate the **earliest behaviorally meaningful divergence** from a trajectory that could still achieve the task under the task's constraints. Do not label every downstream symptom as a new root cause.

## Required fields

For each event record: step, taxonomy label, concise evidence, root-cause flag, confidence, recoverability class, and recovery window. Add causal edges only when the downstream error would likely not have occurred without the upstream event.

## Root cause test

Ask: *If this event were corrected while keeping prior history fixed, would the later failure probably disappear?* If yes, it is a causal candidate. If multiple independent causes exist, annotate each.

## Recoverability

- R0 no intervention
- R1 repeat/correct one local action
- R2 inspect/reconstruct local state
- R3 replan current subgoal
- R4 replan globally
- R5 rollback/checkpoint needed
- R6 human clarification needed
- R7 irrecoverable under benchmark constraints

## Point of no return

Earliest step after which no allowed agent action can satisfy all success and safety constraints without external reset or forbidden intervention.

## Human calibration protocol

Double-annotate the gold subset. Report Cohen's kappa for categorical taxonomy/recoverability, raw agreement for root-cause flag, and interval overlap / absolute difference for recovery-window boundaries. Adjudicate disagreements before freezing benchmark labels.
